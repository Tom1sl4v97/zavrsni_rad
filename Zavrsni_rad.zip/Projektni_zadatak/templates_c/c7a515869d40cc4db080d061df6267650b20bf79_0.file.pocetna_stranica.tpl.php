<?php
/* Smarty version 3.1.39, created on 2021-08-24 22:22:28
  from 'C:\xampp\htdocs\Projektni_zadatak\templates\Pocetna_stranica\pocetna_stranica.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_612555043acca0_44361494',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c7a515869d40cc4db080d061df6267650b20bf79' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Projektni_zadatak\\templates\\Pocetna_stranica\\pocetna_stranica.tpl',
      1 => 1629836547,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_612555043acca0_44361494 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_checkPlugins(array(0=>array('file'=>'C:\\xampp\\htdocs\\Projektni_zadatak\\vanjske_biblioteke\\smarty-3.1.39\\libs\\plugins\\modifier.date_format.php','function'=>'smarty_modifier_date_format',),));
?>
<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
CSS/popUp_prozor.css"/>
<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
CSS/prikaz_forme.css"/>
<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
CSS/prikaz_izlozbe.css"/>
<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
CSS/prikaz_teblice.css"/>

<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
javascript/zatvaranje_pop_up_prozora.js" ><?php echo '</script'; ?>
>

<section>
    <?php if ((isset($_smarty_tpl->tpl_vars['podaci_korisnika']->value))) {?>
        <div class="popUp" id="popUpPrihvaćanjaUvjetaKoristenja" style="display: block">
            <div class="popUpPozadina">
                <div id="odustani" class="odustani"> X </div>
                <h2 style="padding: 0">Prihvaćate li uvjete korištenja, zapis podataka u kolačić o prijavi</h2>
                <h2 id="textIzlozbe" style="padding: 0"></h2>
                <br>
                <div id="bezVlakova"></div>
                <form class="popUpForma">
                    <a class="gumbPrijava" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
korisnici/prihvacivanje_uvjeta_koristenja/<?php echo $_smarty_tpl->tpl_vars['podaci_korisnika']->value->id;?>
">Prihvaćam</a>
                    <a class="gumbPrijava" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
korisnici/prihvacivanje_uvjeta_koristenja/">Ne prihvaćam</a>
                </form>
            </div>
        </div>
    <?php }?>

    <?php if ((isset($_smarty_tpl->tpl_vars['istekloVrijeme']->value))) {?>
        <?php echo $_smarty_tpl->tpl_vars['istekloVrijeme']->value;?>

    <?php } else { ?>
        <h2>
            Prikaz završenih izložbi i pobjednika izložbe
        </h2>
        <div class="resetka">
            <?php
$__section_i_0_loop = (is_array(@$_loop=$_smarty_tpl->tpl_vars['izlozba']->value) ? count($_loop) : max(0, (int) $_loop));
$__section_i_0_total = $__section_i_0_loop;
$_smarty_tpl->tpl_vars['__smarty_section_i'] = new Smarty_Variable(array());
if ($__section_i_0_total !== 0) {
for ($__section_i_0_iteration = 1, $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] = 0; $__section_i_0_iteration <= $__section_i_0_total; $__section_i_0_iteration++, $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']++){
?>
                <div style="margin-bottom: 30px">
                    <div class="izlozbaVlakova">
                        <div class="slika">
                            <?php $_smarty_tpl->_assignInScope('nemaSlike', "ne");?>
                            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['izbor_slike']->value, 'val', false, 'key');
$_smarty_tpl->tpl_vars['val']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['key']->value => $_smarty_tpl->tpl_vars['val']->value) {
$_smarty_tpl->tpl_vars['val']->do_else = false;
?>
                                <?php if ($_smarty_tpl->tpl_vars['izlozba']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->naziv_tematike == $_smarty_tpl->tpl_vars['val']->value) {?>
                                    <img src="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
/multimedija/prikazTeme/<?php echo $_smarty_tpl->tpl_vars['key']->value;?>
.jpg" alt="<?php echo $_smarty_tpl->tpl_vars['key']->value;?>
" style="width: 100%;margin: 0; padding: 0;">
                                    <?php $_smarty_tpl->_assignInScope('nemaSlike', "da");?>
                                    <?php $_smarty_tpl->_assignInScope('naslovnaSlike', $_smarty_tpl->tpl_vars['key']->value);?>
                                <?php }?>
                            <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                            <?php if ($_smarty_tpl->tpl_vars['nemaSlike']->value == "ne") {?>
                                <img src="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
/multimedija/prikazTeme/ostalo.jpg" alt="<?php echo $_smarty_tpl->tpl_vars['izlozba']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->naziv_tematike;?>
" style="width: 100%;margin: 0; padding: 0;">
                            <?php }?>
                        </div>
                        <div class="naslov">
                            <?php echo $_smarty_tpl->tpl_vars['izlozba']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->naziv_tematike;?>

                            <?php ob_start();
echo $_smarty_tpl->tpl_vars['izlozba']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->trenutni_broj_korisnika;
$_prefixVariable1 = ob_get_clean();
if ($_prefixVariable1 != 0) {?>
                                <a class="dodaj2" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
pocetna_stranica/index/<?php echo $_smarty_tpl->tpl_vars['izlozba']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->id;?>
/">
                                    Detalji prijave
                                </a>
                            <?php }?>
                        </div>
                        <div>
                            <br>
                            <div class="podkategorije">
                                <?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['izlozba']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->datum_pocetka,"<b>Datum početka:</b> %d.%m.%Y.<br><br><b>Vrijeme početka:</b> %H:%M");?>
<br><br>
                                <b>Popunjeno:</b> <?php echo $_smarty_tpl->tpl_vars['izlozba']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->trenutni_broj_korisnika;?>
 / <?php echo $_smarty_tpl->tpl_vars['izlozba']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->broj_korisnika;?>
<br><br>
                                <b>Status: </b> <?php echo $_smarty_tpl->tpl_vars['izlozba']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->status_izlozbe;?>

                                <?php if ($_smarty_tpl->tpl_vars['podaci_glasanja']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)] != NULL) {?>
                                    <p><b>Pobijednik:</b> <?php echo $_smarty_tpl->tpl_vars['podaci_glasanja']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)][0]->ime;?>
 <?php echo $_smarty_tpl->tpl_vars['podaci_glasanja']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)][0]->prezime;?>
</p>
                                    <p><b>Naziv vlaka:</b> <?php echo $_smarty_tpl->tpl_vars['podaci_glasanja']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)][0]->naziv_vlaka;?>

                                    <p><b>Rezultat: </b> <?php echo $_smarty_tpl->tpl_vars['podaci_glasanja']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)][0]->ukupno_glasova;?>
 / <?php echo $_smarty_tpl->tpl_vars['podaci_glasanja']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)][0]->ukupno_bodova;?>
 (glas/bod)</p>
                                    <form class="prikazForme">
                                        <a class="dodaj" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
vlakovi/prikaz_detalja_prijavljenog_vlaka/<?php echo $_smarty_tpl->tpl_vars['podaci_glasanja']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)][0]->id_prijave_vlaka;?>
/">
                                            Detalji pobjednika
                                        </a>
                                    </form>
                                    <br><br>

                                    <?php
$__section_k_1_loop = (is_array(@$_loop=$_smarty_tpl->tpl_vars['podaci_glasanja']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]) ? count($_loop) : max(0, (int) $_loop));
$_smarty_tpl->tpl_vars['__smarty_section_k'] = new Smarty_Variable(array('total' => $__section_k_1_loop));
if ($_smarty_tpl->tpl_vars['__smarty_section_k']->value['total'] !== 0) {
for ($__section_k_1_iteration = 1, $_smarty_tpl->tpl_vars['__smarty_section_k']->value['index'] = 0; $__section_k_1_iteration <= $_smarty_tpl->tpl_vars['__smarty_section_k']->value['total']; $__section_k_1_iteration++, $_smarty_tpl->tpl_vars['__smarty_section_k']->value['index']++){
$_smarty_tpl->tpl_vars['__smarty_section_k']->value['index_next'] = $_smarty_tpl->tpl_vars['__smarty_section_k']->value['index'] + 1;
?>
                                        <?php if ((isset($_smarty_tpl->tpl_vars['__smarty_section_k']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_k']->value['index'] : null) == 0 && (isset($_smarty_tpl->tpl_vars['__smarty_section_k']->value['total']) ? $_smarty_tpl->tpl_vars['__smarty_section_k']->value['total'] : null) > 1) {?>
                                            <p><b>Ostali sudionici:</b></p>
                                        <?php } elseif ((isset($_smarty_tpl->tpl_vars['__smarty_section_k']->value['total']) ? $_smarty_tpl->tpl_vars['__smarty_section_k']->value['total'] : null) > 1 && (isset($_smarty_tpl->tpl_vars['__smarty_section_k']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_k']->value['index'] : null) < 3) {?>
                                            <?php echo (isset($_smarty_tpl->tpl_vars['__smarty_section_k']->value['index_next']) ? $_smarty_tpl->tpl_vars['__smarty_section_k']->value['index_next'] : null);?>
. 
                                            <?php echo $_smarty_tpl->tpl_vars['podaci_glasanja']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)][(isset($_smarty_tpl->tpl_vars['__smarty_section_k']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_k']->value['index'] : null)]->ime;?>
 
                                            <?php echo $_smarty_tpl->tpl_vars['podaci_glasanja']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)][(isset($_smarty_tpl->tpl_vars['__smarty_section_k']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_k']->value['index'] : null)]->prezime;?>
 - 
                                            <?php echo $_smarty_tpl->tpl_vars['podaci_glasanja']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)][(isset($_smarty_tpl->tpl_vars['__smarty_section_k']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_k']->value['index'] : null)]->korisnicko_ime;?>
: 
                                            <?php echo $_smarty_tpl->tpl_vars['podaci_glasanja']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)][(isset($_smarty_tpl->tpl_vars['__smarty_section_k']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_k']->value['index'] : null)]->naziv_vlaka;?>
 - 
                                            <?php echo $_smarty_tpl->tpl_vars['podaci_glasanja']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)][(isset($_smarty_tpl->tpl_vars['__smarty_section_k']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_k']->value['index'] : null)]->ukupno_glasova;?>
 / 
                                            <?php echo $_smarty_tpl->tpl_vars['podaci_glasanja']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)][(isset($_smarty_tpl->tpl_vars['__smarty_section_k']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_k']->value['index'] : null)]->ukupno_bodova;?>

                                            <br>
                                        <?php }?>
                                    <?php
}
}
?>
                                <?php } else { ?>
                                    <p>Nitko nije glasao</p>
                                <?php }?>


                            </div>
                        </div>
                    </div>
                </div>
            <?php
}
}
?>
        </div>
        <?php if ((isset($_smarty_tpl->tpl_vars['detalji_izlozbe']->value))) {?>
            <div id="RSSKanal">
                <br><br>
                <table class="prikazTablice" style="width: 95%">
                    <caption style="font-size: 24px; padding: 0px 0px 15px 0px;">Prikaz detalja prijave korisnika kod odabrane izlozbe</caption>
                    <thead>
                        <tr>
                            <th>Ime</th>
                            <th>Prezime</th>
                            <th>Korisnicko ime</th>
                            <th>E-mail</th>
                            <th>Naziv vlaka</th>
                            <th>Naziv tematike izlozbe</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
$__section_i_2_loop = (is_array(@$_loop=$_smarty_tpl->tpl_vars['detalji_izlozbe']->value) ? count($_loop) : max(0, (int) $_loop));
$__section_i_2_total = $__section_i_2_loop;
$_smarty_tpl->tpl_vars['__smarty_section_i'] = new Smarty_Variable(array());
if ($__section_i_2_total !== 0) {
for ($__section_i_2_iteration = 1, $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] = 0; $__section_i_2_iteration <= $__section_i_2_total; $__section_i_2_iteration++, $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']++){
?>
                            <tr>
                                <td><?php echo $_smarty_tpl->tpl_vars['detalji_izlozbe']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->ime_korisnika;?>
</td>
                                <td><?php echo $_smarty_tpl->tpl_vars['detalji_izlozbe']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->prezime_korisnika;?>
</td>
                                <td><?php echo $_smarty_tpl->tpl_vars['detalji_izlozbe']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->korisnicko_ime;?>
</td>
                                <td><?php echo $_smarty_tpl->tpl_vars['detalji_izlozbe']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->email;?>
</td>
                                <td><?php echo $_smarty_tpl->tpl_vars['detalji_izlozbe']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->naziv;?>
</td>
                                <td><?php echo $_smarty_tpl->tpl_vars['detalji_izlozbe']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->naziv_tematike;?>
</td>
                            </tr>
                        <?php
}
}
?>
                    </tbody>
                </table>
                <br><br>
            </div>
        <?php }?>
    <?php }?>
</section>

<?php }
}
