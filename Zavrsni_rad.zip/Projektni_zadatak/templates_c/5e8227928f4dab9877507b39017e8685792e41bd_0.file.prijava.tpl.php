<?php
/* Smarty version 3.1.39, created on 2021-08-20 22:06:41
  from 'C:\xampp\htdocs\Projektni_zadatak\templates\Korisnici\prijava.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_61200b51a1ae68_71685277',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5e8227928f4dab9877507b39017e8685792e41bd' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Projektni_zadatak\\templates\\Korisnici\\prijava.tpl',
      1 => 1629490000,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_61200b51a1ae68_71685277 (Smarty_Internal_Template $_smarty_tpl) {
?><link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
CSS/prikaz_forme.css"/>
<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
CSS/popUp_prozor.css"/>
<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
CSS/popUp_pomoc_prijave.css"/>

<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
javascript/prikaz_pomoci.js"><?php echo '</script'; ?>
>

<section id="sadrzajObrasca">

    <div id="kutijaDizajnaPomoci">
        <button type="submit" class="slikaGumbaPomoci" onclick="popUpUpitnik()"></button>
    </div>

    <div>
        <div class="popUp" id="popUpPomoc">
            <div class="popUpPozadina">
                Trebate li pomoć?<br><br>
                <div id="pomocDa1" style="float: left;width: 100px;">
                    Da
                </div>
                <div id="pomocNe1" style="float: left;width: 100px">
                    Ne
                </div>
                <br>
            </div>
        </div> 
        <div id="pravokutnik1" class="pravokutnik1">
            Ovo je navigacija
        </div>
        <div id="pravokutnik2" class="pravokutnik2">
            Ovdje se vrši unos podataka.
        </div>
        <div id="pravokutnik3" class="pravokutnik3">
            Unos postojećeg korisničkog imena.
        </div>
        <div id="pravokutnik4" class="pravokutnik4">
            Unos lozinke korisnika.
        </div>
        <div id="pravokutnik5" class="pravokutnik5">
            Zapamćuje korisničko ime korisnika.
        </div>
        <div id="pravokutnik6" class="pravokutnik6">
            Ako korisnik ne posijeduje račun,<br> mora kliknuti na "nemate račun?"
        </div>
        <div id="pravokutnik7" class="pravokutnik7">
            Kada ste sve popunili, morate<br>kliknuti na gumb "Prijavi se" 
        </div>

        <form novalidate method="post" action="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
korisnici/prijava_korisnika/">
            <br>
            <label for="korime">Korisničko ime: </label>
            <input class="okvirForme" type="text" id="korime" name="korime"
                   <?php if ((isset($_smarty_tpl->tpl_vars['korisnicko_ime']->value))) {?>
                       value="<?php echo $_smarty_tpl->tpl_vars['korisnicko_ime']->value;?>
"
                   <?php }?>>
            <br><br>
            <label for="lozinka">Lozinka: </label>
            <input class="okvirForme" type="password" id="lozinka" name="lozinka">
            <br><br>
            <a class="gumbPrijava" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
korisnici/prijava_tesnog_korisnika/3">Registrirani korisnik</a>
            <a class="gumbPrijava" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
korisnici/prijava_tesnog_korisnika/2">Moderator</a>
            <a class="gumbPrijava" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
korisnici/prijava_tesnog_korisnika/1">Administrator</a>
            <br><br>
            <label for="zapamtiMe"> Zapamti me</label>
            <input type="checkbox" id="zapamtiMe"  name="zapamtiMe" value="da" style="width: 18px;height: 18px" 
                   <?php if ($_smarty_tpl->tpl_vars['korisnicko_ime']->value) {?>
                       checked
                   <?php }?>>
            <br><br>

            <a href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
korisnici/prebaci_na_registraciju/" style="text-decoration: none;"> Nemate račun?</a>
            <br><br>
            <input class="gumbPrijava" type="submit" value="Prijavi se">
            <br><br>
        </form>
    </div>
</section>
<?php }
}
