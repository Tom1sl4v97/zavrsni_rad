<?php
/* Smarty version 3.1.39, created on 2021-08-19 17:03:15
  from 'C:\xampp\htdocs\Projektni_zadatak\templates\Izlozbe\azuriranje_izlozbe.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_611e72b3f3fd36_81456850',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2c8735f99c7abce6529223be734053ac5d277745' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Projektni_zadatak\\templates\\Izlozbe\\azuriranje_izlozbe.tpl',
      1 => 1629385195,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_611e72b3f3fd36_81456850 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_checkPlugins(array(0=>array('file'=>'C:\\xampp\\htdocs\\Projektni_zadatak\\vanjske_biblioteke\\smarty-3.1.39\\libs\\plugins\\modifier.date_format.php','function'=>'smarty_modifier_date_format',),));
?>
<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
CSS/prikaz_forme.css"/>
<section id="sadrzajObrasca">
    <div>
        <br>
        <form id ="form1" method="post" name="dodavanjeNoveTematike" action="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
izlozbe/azuriraj_izlozbu/<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
">
            <br>

            <label for="odabirModeratoraTematike">Odaberite željenu temu izložbe vlaka:</label><br>
            <select name="odabirModeratoraTematike" id="odabirModeratoraTematike" class="prikazDropDown">
                <option value="0" class="prikazDropDown">Odaberite</option>
                <?php
$__section_i_0_loop = (is_array(@$_loop=$_smarty_tpl->tpl_vars['popis_teme_izlozbe']->value) ? count($_loop) : max(0, (int) $_loop));
$__section_i_0_total = $__section_i_0_loop;
$_smarty_tpl->tpl_vars['__smarty_section_i'] = new Smarty_Variable(array());
if ($__section_i_0_total !== 0) {
for ($__section_i_0_iteration = 1, $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] = 0; $__section_i_0_iteration <= $__section_i_0_total; $__section_i_0_iteration++, $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']++){
?>
                    <option value="<?php echo $_smarty_tpl->tpl_vars['popis_teme_izlozbe']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->tematika_id;?>
" class="prikazDropDown" 
                            <?php if ((isset($_smarty_tpl->tpl_vars['uredi_temu']->value))) {?>
                                <?php if ($_smarty_tpl->tpl_vars['uredi_temu']->value == $_smarty_tpl->tpl_vars['popis_teme_izlozbe']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->tematika_id) {?>}
                                    selected
                                <?php }?>
                            <?php }?>>
                        <?php echo $_smarty_tpl->tpl_vars['popis_teme_izlozbe']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->naziv_tematike;?>

                    </option>
                <?php
}
}
?>
            </select><br><br>
            <label for="datumPocetka">Unesite datum početka izložbe: </label>
            <input class="okvirForme2" type="datetime-local" id="datumPocetka" name="datumPocetka"
                   <?php if ((isset($_smarty_tpl->tpl_vars['uredi_datum']->value))) {?>
                       value="<?php echo $_smarty_tpl->tpl_vars['uredi_datum']->value[0];?>
T<?php echo $_smarty_tpl->tpl_vars['uredi_datum']->value[1];?>
"
                   <?php }?>>
            <br><br>
            <label for="maxBrojKorisnika">Maksimalan broj korisnika: </label>
            <input class="okvirForme2" type="number" id="maxBrojKorisnika" name="maxBrojKorisnika"
                   <?php if ((isset($_smarty_tpl->tpl_vars['uredi_max_korisnika']->value))) {?>
                       value="<?php echo $_smarty_tpl->tpl_vars['uredi_max_korisnika']->value;?>
"
                   <?php }?>
                   ><br><br>

            <label for="pocetakGlasovanja">Početak glasovanja</label><br>
            <input type="date" id="datum" name="pocetakGlasovanja" class="okvirForme2"
                   <?php if (!empty($_smarty_tpl->tpl_vars['id']->value)) {?>
                       value="<?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['uredi_Datum']->value->vazi_od,"Y-m-d");?>
"
                   <?php }?>
                   ><br><br>
            <label for="zavrsetakGlasovanja">Završetak glasovanje</label><br>
            <input type="date" id="datum" name="zavrsetakGlasovanja" class="okvirForme2"
                   <?php if (!empty($_smarty_tpl->tpl_vars['id']->value)) {?>
                       value="<?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['uredi_Datum']->value->vazi_do,"Y-m-d");?>
"
                   <?php }?>
                   ><br><br>


            <input class="gumbPrijava" type="submit" name="dodajModeratoraTematike" value="Dodaj izložbu">
            <a class="gumbPrijava" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
izlozbe/prikaz_uredivanje_izlozba/">Odustani</a>
            <br><br>
        </form>
        <br>
    </div>
</section>
<?php }
}
