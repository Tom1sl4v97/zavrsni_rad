<?php
/* Smarty version 3.1.39, created on 2021-08-12 17:00:45
  from 'C:\xampp\htdocs\Projektni_zadatak\templates\Izlozbe\uredivanje_izlozba.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_6115379d1fadf6_75950256',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c5e15578b5d46912c8a3eacfef0dffc93623721c' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Projektni_zadatak\\templates\\Izlozbe\\uredivanje_izlozba.tpl',
      1 => 1628250121,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6115379d1fadf6_75950256 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_checkPlugins(array(0=>array('file'=>'C:\\xampp\\htdocs\\Projektni_zadatak\\vanjske_biblioteke\\smarty-3.1.39\\libs\\plugins\\modifier.date_format.php','function'=>'smarty_modifier_date_format',),));
?>
<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
CSS/prikaz_izlozbe.css"/>
<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
CSS/prikaz_forme.css"/>

<section>
    <?php if ((isset($_smarty_tpl->tpl_vars['popis_tematike_vlakova']->value))) {?>
        <h2>
            Tematike vlakova
        </h2>

        <div class="resetka">
            <?php
$__section_i_0_loop = (is_array(@$_loop=$_smarty_tpl->tpl_vars['popis_tematike_vlakova']->value) ? count($_loop) : max(0, (int) $_loop));
$_smarty_tpl->tpl_vars['__smarty_section_i'] = new Smarty_Variable(array('total' => $__section_i_0_loop));
if ($_smarty_tpl->tpl_vars['__smarty_section_i']->value['total'] !== 0) {
for ($__section_i_0_iteration = 1, $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] = 0; $__section_i_0_iteration <= $_smarty_tpl->tpl_vars['__smarty_section_i']->value['total']; $__section_i_0_iteration++, $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']++){
?>
                <?php if ($_smarty_tpl->tpl_vars['popis_tematike_vlakova']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->vazi_do >= $_smarty_tpl->tpl_vars['virtualni_datum']->value || !(isset($_smarty_tpl->tpl_vars['popis_tematike_vlakova']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->vazi_do))) {?>
                    <div style="margin-bottom: 20px; max-width: 400px">
                        <div class="izlozbaVlakova">
                            <div class="slika">
                                <?php $_smarty_tpl->_assignInScope('nemaSlike', "ne");?>
                                <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['izbor_slika']->value, 'val', false, 'key');
$_smarty_tpl->tpl_vars['val']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['key']->value => $_smarty_tpl->tpl_vars['val']->value) {
$_smarty_tpl->tpl_vars['val']->do_else = false;
?>
                                    <?php if ($_smarty_tpl->tpl_vars['popis_tematike_vlakova']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->naziv_tematike == $_smarty_tpl->tpl_vars['val']->value) {?>
                                        <img src="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
multimedija/prikazTeme/<?php echo $_smarty_tpl->tpl_vars['key']->value;?>
.jpg" alt="<?php echo $_smarty_tpl->tpl_vars['key']->value;?>
" width="100%">
                                        <?php $_smarty_tpl->_assignInScope('nemaSlike', "da");?>
                                    <?php }?>
                                <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                                <?php if ($_smarty_tpl->tpl_vars['nemaSlike']->value == "ne") {?>
                                    <img src="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
multimedija/prikazTeme/ostalo.jpg" alt="<?php echo $_smarty_tpl->tpl_vars['popis_tematike_vlakova']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->naziv_tematike;?>
" style="width: 100%;margin: 0; padding: 0;">
                                <?php }?>
                            </div>
                            <div class="naslov">
                                <?php echo $_smarty_tpl->tpl_vars['popis_tematike_vlakova']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->naziv_tematike;?>

                            </div>
                            <div>
                                <div class="podkategorije">
                                    <?php echo $_smarty_tpl->tpl_vars['popis_tematike_vlakova']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->opis_tematike;?>

                                </div>
                                <div class="podkategorije2">
                                    <?php if ($_smarty_tpl->tpl_vars['popis_tematike_vlakova']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->vazi_do != "0000-00-00 00:00:00" && $_SESSION['uloga'] != 1) {?>
                                        Ističe Vam do: <?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['popis_tematike_vlakova']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->vazi_do,"d.m.Y.");?>

                                    <?php } else { ?>
                                        Nemate vremenski rok
                                    <?php }?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php }?>
            <?php
}
}
?>
        </div>
        <br>
        <h3>
            Ukupni broj tema vlakova iznosi: <?php echo (isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['total']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['total'] : null);?>

        </h3>
        <br>
    <?php }?>

    <a class="gumbPrijava2" style="float: right" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
izlozbe/prikaz_azuriranje_izlozbi/">Dodaj novu izlozbu</a>
    <h2>
        Izlozbe
    </h2>


    <?php if ((isset($_smarty_tpl->tpl_vars['popis_izlozbi']->value))) {?>

        <div class="resetka" style="margin-bottom: 20px;width: 100%">
            <?php
$__section_i_1_loop = (is_array(@$_loop=$_smarty_tpl->tpl_vars['popis_izlozbi']->value) ? count($_loop) : max(0, (int) $_loop));
$_smarty_tpl->tpl_vars['__smarty_section_i'] = new Smarty_Variable(array('total' => $__section_i_1_loop));
if ($_smarty_tpl->tpl_vars['__smarty_section_i']->value['total'] !== 0) {
for ($__section_i_1_iteration = 1, $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] = 0; $__section_i_1_iteration <= $_smarty_tpl->tpl_vars['__smarty_section_i']->value['total']; $__section_i_1_iteration++, $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']++){
?>
                <div style="margin-bottom: 20px; max-width: 400px">
                    <div class="izlozbaVlakova">
                        <div class="slika">
                            <?php $_smarty_tpl->_assignInScope('nemaSlike', "ne");?>
                            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['izbor_slika']->value, 'val', false, 'key');
$_smarty_tpl->tpl_vars['val']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['key']->value => $_smarty_tpl->tpl_vars['val']->value) {
$_smarty_tpl->tpl_vars['val']->do_else = false;
?>
                                <?php if ($_smarty_tpl->tpl_vars['popis_izlozbi']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->naziv_tematike == $_smarty_tpl->tpl_vars['val']->value) {?>
                                    <img src="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
multimedija/prikazTeme/<?php echo $_smarty_tpl->tpl_vars['key']->value;?>
.jpg" alt="<?php echo $_smarty_tpl->tpl_vars['key']->value;?>
" style="width: 100%;margin: 0; padding: 0;">
                                    <?php $_smarty_tpl->_assignInScope('nemaSlike', "da");?>
                                <?php }?>
                            <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                            <?php if ($_smarty_tpl->tpl_vars['nemaSlike']->value == "ne") {?>
                                <img src="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
multimedija/prikazTeme/ostalo.jpg" alt="<?php echo $_smarty_tpl->tpl_vars['popis_izlozbi']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->naziv_tematike;?>
" style="width: 100%;margin: 0; padding: 0;">
                            <?php }?>
                        </div>
                        <div class="naslov">
                            <?php echo $_smarty_tpl->tpl_vars['popis_izlozbi']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->naziv_tematike;?>

                        </div>
                        <br>
                        <div>
                            <div class="podkategorije">
                                Datum početka izložbe: <?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['popis_izlozbi']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->datum_pocetka,"%d.%m.%Y <br>otvaranje: %H:%M");?>

                            </div>
                            <div class="podkategorije">
                                Maximalni broj korisnika: <?php echo $_smarty_tpl->tpl_vars['popis_izlozbi']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->broj_korisnika;?>

                            </div>
                            <div class="podkategorije">
                                Status izložbe: <?php echo $_smarty_tpl->tpl_vars['popis_izlozbi']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->status_izlozbe;?>

                            </div>
                        </div>
                        <?php if ($_smarty_tpl->tpl_vars['popis_izlozbi']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->status_izlozbe == "Otvorene prijave") {?>
                            <div style="float: bottom">
                                <div style="padding: 0 5px">
                                    <a class="dodaj" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
izlozbe/prikaz_azuriranje_izlozbi/<?php echo $_smarty_tpl->tpl_vars['popis_izlozbi']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->id;?>
">Uredi izlozbu</a>
                                    <a class="dodaj" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
izlozbe/obrisi_izlozbu/<?php echo $_smarty_tpl->tpl_vars['popis_izlozbi']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->id;?>
">Obriši izlozbu</a>
                                </div>
                            </div>
                        <?php }?>
                    </div>
                </div>
            <?php
}
}
?>
        </div>
        <h3>
            Ukupni broj izložbi iznosi: <?php echo (isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['total']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['total'] : null);?>

        </h3>
    <?php }?>
</section>
<?php }
}
