<?php
/* Smarty version 3.1.39, created on 2021-08-14 15:59:48
  from 'C:\xampp\htdocs\Projektni_zadatak\templates\dijeljeno\podnozje.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_6117cc54e60939_36523549',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '091c44323461cea1f2552c305b4820b1d0bcf052' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Projektni_zadatak\\templates\\dijeljeno\\podnozje.tpl',
      1 => 1628949587,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6117cc54e60939_36523549 (Smarty_Internal_Template $_smarty_tpl) {
?><footer>
    <br>
    <a>Kontakt: </a>
    <a href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
pocetna_stranica/autor_stranice/">
        <b>Tomislav Tomiek</b>
    </a>
    <a>&copy; 2021</a>
    <br>
    <span>
        <strong>Vrijeme sustava: </strong>
        <?php echo date("d.m.Y. H:i:s");?>

        |
        <strong>Virtualno vrijeme sustava: </strong>
        <?php echo $_smarty_tpl->tpl_vars['virtualnoVrijeme']->value;?>

    </span>
    <br><br>
</footer>
</body>
</html><?php }
}
