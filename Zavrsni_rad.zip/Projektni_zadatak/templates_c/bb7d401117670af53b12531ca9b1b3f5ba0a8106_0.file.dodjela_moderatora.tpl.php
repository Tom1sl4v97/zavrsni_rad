<?php
/* Smarty version 3.1.39, created on 2021-08-14 15:50:19
  from 'C:\xampp\htdocs\Projektni_zadatak\templates\Izlozbe\dodjela_moderatora.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_6117ca1bb1adf9_91141383',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'bb7d401117670af53b12531ca9b1b3f5ba0a8106' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Projektni_zadatak\\templates\\Izlozbe\\dodjela_moderatora.tpl',
      1 => 1628266403,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6117ca1bb1adf9_91141383 (Smarty_Internal_Template $_smarty_tpl) {
?><link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
CSS/prikaz_forme.css"/>
<section id="sadrzajObrasca">
    <div>
        <br>
        <form id ="form1" method="post" name="dodavanjeNoveTematike" action="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
izlozbe/azuriraj_dodijelu_moderatora/<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
">
            <br>

            <label for="odabirModeratoraTematike">Odaberite moderatora za tematiku vlakova:</label><br>
            <select name="odabirModeratoraTematike" id="odabirModeratoraTematike" class="prikazDropDown">
                <option value="0" class="prikazDropDown">Odaberite</option>
                <?php
$__section_i_0_loop = (is_array(@$_loop=$_smarty_tpl->tpl_vars['popis_moderatora']->value) ? count($_loop) : max(0, (int) $_loop));
$__section_i_0_total = $__section_i_0_loop;
$_smarty_tpl->tpl_vars['__smarty_section_i'] = new Smarty_Variable(array());
if ($__section_i_0_total !== 0) {
for ($__section_i_0_iteration = 1, $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] = 0; $__section_i_0_iteration <= $__section_i_0_total; $__section_i_0_iteration++, $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']++){
?>
                    <option value="<?php echo $_smarty_tpl->tpl_vars['popis_moderatora']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->id;?>
" class="prikazDropDown"
                            <?php if ((isset($_smarty_tpl->tpl_vars['podaci_uredivanja_moderatora_tematike']->value['id_moderator_tematike_vlakova']))) {?>
                                <?php if ($_smarty_tpl->tpl_vars['podaci_uredivanja_moderatora_tematike']->value['id_moderator_tematike_vlakova'] == $_smarty_tpl->tpl_vars['popis_moderatora']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->id) {?>}
                                    selected
                                <?php }?>
                            <?php }?>
                            >
                        <?php echo $_smarty_tpl->tpl_vars['popis_moderatora']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->ime;?>
 <?php echo $_smarty_tpl->tpl_vars['popis_moderatora']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->prezime;?>
 - <?php echo $_smarty_tpl->tpl_vars['popis_moderatora']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->korisnicko_ime;?>

                    </option>
                <?php
}
}
?>
            </select><br><br>

            <label for="odabirTematike">Odaberite postojeću tematiku vlakova:</label><br>
            <select name="odabirTematike" id="odabirTeamtike" class="prikazDropDown">
                <option value="0" class="prikazDropDown">Odaberite</option>
                <?php
$__section_i_1_loop = (is_array(@$_loop=$_smarty_tpl->tpl_vars['popis_tematike_vlakova']->value) ? count($_loop) : max(0, (int) $_loop));
$__section_i_1_total = $__section_i_1_loop;
$_smarty_tpl->tpl_vars['__smarty_section_i'] = new Smarty_Variable(array());
if ($__section_i_1_total !== 0) {
for ($__section_i_1_iteration = 1, $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] = 0; $__section_i_1_iteration <= $__section_i_1_total; $__section_i_1_iteration++, $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']++){
?>
                    <option value="<?php echo $_smarty_tpl->tpl_vars['popis_tematike_vlakova']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->id;?>
" class="prikazDropDown"
                            <?php if ((isset($_smarty_tpl->tpl_vars['podaci_uredivanja_moderatora_tematike']->value['id_tematika_vlakova']))) {?>
                                <?php if ($_smarty_tpl->tpl_vars['podaci_uredivanja_moderatora_tematike']->value['id_tematika_vlakova'] == $_smarty_tpl->tpl_vars['popis_tematike_vlakova']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->id) {?>}
                                    selected
                                <?php }?>
                            <?php }?>
                            ><?php echo $_smarty_tpl->tpl_vars['popis_tematike_vlakova']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->naziv;?>
</option>
                <?php
}
}
?>
            </select><br><br>

            <label for="datumOd">Unesite datum od kada vrijedi zadani moderator:</label><br>
            <input type="date" id="datum" name="datumOd" class="okvirForme2"
                   <?php if ((isset($_smarty_tpl->tpl_vars['podaci_uredivanja_moderatora_tematike']->value['vrijedi_od']))) {?>
                       value="<?php echo $_smarty_tpl->tpl_vars['podaci_uredivanja_moderatora_tematike']->value['vrijedi_od'];?>
"
                   <?php }?>
                   ><br><br>

            <label for="datumDo">Unesite datum do kada vrijedi zadani moderator:</label><br>
            <input type="date" id="datum" name="datumDo" class="okvirForme2"
                   <?php if ((isset($_smarty_tpl->tpl_vars['podaci_uredivanja_moderatora_tematike']->value['vrijedi_do']))) {?>
                       value="<?php echo $_smarty_tpl->tpl_vars['podaci_uredivanja_moderatora_tematike']->value['vrijedi_do'];?>
"
                   <?php }?>
                   >
            <br><br>

            <input class="gumbPrijava" type="submit" name="spremi" value="Spremi">
            <a class="gumbPrijava" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
izlozbe/prikaz_administracija_izlozba/">Odustani</a>
            <br><br>
        </form>
        <br>
    </div>
</section>
<?php }
}
