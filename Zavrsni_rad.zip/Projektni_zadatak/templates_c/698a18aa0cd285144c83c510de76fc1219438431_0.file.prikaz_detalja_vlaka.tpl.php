<?php
/* Smarty version 3.1.39, created on 2021-08-12 16:59:37
  from 'C:\xampp\htdocs\Projektni_zadatak\templates\Vlakovi\prikaz_detalja_vlaka.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_61153759750693_21459607',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '698a18aa0cd285144c83c510de76fc1219438431' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Projektni_zadatak\\templates\\Vlakovi\\prikaz_detalja_vlaka.tpl',
      1 => 1628356875,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_61153759750693_21459607 (Smarty_Internal_Template $_smarty_tpl) {
?><link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
CSS/prikaz_galerije.css"/>

<style>
    .prikazTeksta{
        padding: 0 0 0 30px;
    }
    .resetka {
        display: grid;
        grid-template-columns: auto auto auto;
    }
    section{
        font-size: 20px;
    }

    @media only screen and (min-width: 0px) and (max-width: 1300px){
        .resetka {
            display: grid;
            grid-template-columns: auto;
        }
    }
</style>

<section>
    <?php if ((isset($_smarty_tpl->tpl_vars['informacije_vlaka_korisnika']->value))) {?>
        <h2 class="naslovPravi">Informacije o prijavi vlaka</h2>
        <br><br>
        <div class="prikazTeksta, resetka">
            <div width="33%">
                <h2 style="padding-bottom: 10px">
                    <b>Korisnik:</b>
                </h2>
                <div class="prikazTeksta">
                    <b style="padding-right: 108px">Ime: </b><?php echo $_smarty_tpl->tpl_vars['informacije_vlaka_korisnika']->value->ime_korisnika;?>
<br><br>
                    <b style="padding-right: 67px">Prezime:</b> <?php echo $_smarty_tpl->tpl_vars['informacije_vlaka_korisnika']->value->prezime_korisnika;?>
<br><br>
                    <b>Korisnicko ime:</b> <?php echo $_smarty_tpl->tpl_vars['informacije_vlaka_korisnika']->value->korisnicko_ime;?>
<br><br>
                    <address><b style="padding-right: 88px">E-mail:</b><a href="mailto:<?php echo $_smarty_tpl->tpl_vars['informacije_vlaka_korisnika']->value->email;?>
" style="text-decoration: none;"><?php echo $_smarty_tpl->tpl_vars['informacije_vlaka_korisnika']->value->email;?>
</a></address><br><br>
                </div>
            </div>
            <div width="33%">
                <h2 style="padding-bottom: 10px">
                    <b>Vlak:</b>
                </h2>
                <div class="prikazTeksta">
                    <b style="padding-right: 89px">Ime vlaka:</b> <?php echo $_smarty_tpl->tpl_vars['informacije_vlaka_korisnika']->value->naziv;?>
<br><br>
                    <b>Maksimalna brzina:</b> <?php echo $_smarty_tpl->tpl_vars['informacije_vlaka_korisnika']->value->max_brzina;?>
 km/h<br><br>
                    <b style="padding-right: 66px">Broj sjedala:</b> <?php echo $_smarty_tpl->tpl_vars['informacije_vlaka_korisnika']->value->broj_sjedala;?>
<br><br>
                    <b>Opis vlaka:</b><br> <?php echo $_smarty_tpl->tpl_vars['informacije_vlaka_korisnika']->value->opis;?>
<br><br>
                </div>
            </div>
            <div width="33%">
                <h2 style="padding-bottom: 10px">
                    <b>Pogon:</b>
                </h2>
                <div class="prikazTeksta">
                    <b>Naziv pogona:</b> <?php echo $_smarty_tpl->tpl_vars['informacije_vlaka_korisnika']->value->naziv_pogona;?>
<br><br>
                    <b>Opis pogona:</b><br> <?php echo $_smarty_tpl->tpl_vars['informacije_vlaka_korisnika']->value->opis_pogona;?>
<br><br>
                </div>
            </div>
        </div>
        <br><br>
        <?php if (!empty($_smarty_tpl->tpl_vars['slike_korisnika']->value)) {?>
            <h3>
                Galerija slika korisnika
            </h3>
            <div class="mjestoKutije">
                <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['slike_korisnika']->value, 'val', false, 'key', 'foo', array (
  'index' => true,
));
$_smarty_tpl->tpl_vars['val']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['key']->value => $_smarty_tpl->tpl_vars['val']->value) {
$_smarty_tpl->tpl_vars['val']->do_else = false;
$_smarty_tpl->tpl_vars['__smarty_foreach_foo']->value['index']++;
?>
                    <?php if (((isset($_smarty_tpl->tpl_vars['__smarty_foreach_foo']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_foreach_foo']->value['index'] : null)%4) == 0 && (isset($_smarty_tpl->tpl_vars['__smarty_foreach_foo']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_foreach_foo']->value['index'] : null) != 0) {?>
                    </div>
                    <div class="mjestoKutije">
                        <div class="kutija">
                            <img src="<?php echo $_smarty_tpl->tpl_vars['val']->value->url;?>
">
                            <p><?php echo $_smarty_tpl->tpl_vars['naziv_slike']->value[$_smarty_tpl->tpl_vars['key']->value];?>
</p>
                        </div>
                    <?php } else { ?>
                        <div class="kutija">
                            <img src="<?php echo $_smarty_tpl->tpl_vars['val']->value->url;?>
">
                            <p><?php echo $_smarty_tpl->tpl_vars['naziv_slike']->value[$_smarty_tpl->tpl_vars['key']->value];?>
</p>
                        </div>
                    <?php }?>
                <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
            </div>
            <br>
        <?php }?>

        <?php if (!empty($_smarty_tpl->tpl_vars['video_korisnika']->value)) {?>
            <h3>
                Galerija videa korisnika
            </h3>
            <div class="mjestoKutije">
                <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['video_korisnika']->value, 'val', false, 'key', 'foo', array (
  'index' => true,
));
$_smarty_tpl->tpl_vars['val']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['key']->value => $_smarty_tpl->tpl_vars['val']->value) {
$_smarty_tpl->tpl_vars['val']->do_else = false;
$_smarty_tpl->tpl_vars['__smarty_foreach_foo']->value['index']++;
?>
                    <?php if (((isset($_smarty_tpl->tpl_vars['__smarty_foreach_foo']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_foreach_foo']->value['index'] : null)%4) == 0 && (isset($_smarty_tpl->tpl_vars['__smarty_foreach_foo']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_foreach_foo']->value['index'] : null) != 0) {?>
                    </div>
                    <div class="mjestoKutije">
                        <div class="kutija">
                            <video controls><source src="<?php echo $_smarty_tpl->tpl_vars['val']->value->url;?>
" type="video/mp4" class="video"></video>
                            <p><?php echo $_smarty_tpl->tpl_vars['naziv_videa']->value[$_smarty_tpl->tpl_vars['key']->value];?>
</p>
                        </div>
                    <?php } else { ?>
                        <div class="kutija">
                            <video controls><source src="<?php echo $_smarty_tpl->tpl_vars['val']->value->url;?>
" type="video/mp4" class="video"></video>
                            <p><?php echo $_smarty_tpl->tpl_vars['naziv_videa']->value[$_smarty_tpl->tpl_vars['key']->value];?>
</p>
                        </div>
                    <?php }?>
                <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
            </div>
        <?php }?>
        <?php if (!empty($_smarty_tpl->tpl_vars['audio_korisnika']->value)) {?>
            <h3>
                Galerija audia korisnika
            </h3>
            <div class="mjestoKutije" style="height: 200px">
                <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['audio_korisnika']->value, 'val', false, 'key', 'foo', array (
  'index' => true,
));
$_smarty_tpl->tpl_vars['val']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['key']->value => $_smarty_tpl->tpl_vars['val']->value) {
$_smarty_tpl->tpl_vars['val']->do_else = false;
$_smarty_tpl->tpl_vars['__smarty_foreach_foo']->value['index']++;
?>
                    <?php if (((isset($_smarty_tpl->tpl_vars['__smarty_foreach_foo']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_foreach_foo']->value['index'] : null)%4) == 0 && (isset($_smarty_tpl->tpl_vars['__smarty_foreach_foo']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_foreach_foo']->value['index'] : null) != 0) {?>
                    </div>
                    <div class="mjestoKutije" style="height: 200px">
                        <div class="kutija">
                            <audio controls><source src="<?php echo $_smarty_tpl->tpl_vars['val']->value->url;?>
" type="video/mp4" class="video"></audio>
                            <p><?php echo $_smarty_tpl->tpl_vars['naziv_audia']->value[$_smarty_tpl->tpl_vars['key']->value];?>
</p>
                        </div>
                    <?php } else { ?>
                        <div class="kutija">
                            <audio controls><source src="<?php echo $_smarty_tpl->tpl_vars['val']->value->url;?>
" type="video/mp4" class="video"></audio>
                            <p><?php echo $_smarty_tpl->tpl_vars['naziv_audia']->value[$_smarty_tpl->tpl_vars['key']->value];?>
</p>
                        </div>
                    <?php }?>
                <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
            </div>
        <?php }?>
        <?php if (!empty($_smarty_tpl->tpl_vars['gif_korisnika']->value)) {?>
            <h3>
                Galerija gifova korisnika
            </h3>
            <div class="mjestoKutije">
                <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['gif_korisnika']->value, 'val', false, 'key', 'foo', array (
  'index' => true,
));
$_smarty_tpl->tpl_vars['val']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['key']->value => $_smarty_tpl->tpl_vars['val']->value) {
$_smarty_tpl->tpl_vars['val']->do_else = false;
$_smarty_tpl->tpl_vars['__smarty_foreach_foo']->value['index']++;
?>
                    <?php if (((isset($_smarty_tpl->tpl_vars['__smarty_foreach_foo']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_foreach_foo']->value['index'] : null)%4) == 0 && (isset($_smarty_tpl->tpl_vars['__smarty_foreach_foo']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_foreach_foo']->value['index'] : null) != 0) {?>
                    </div>
                    <div class="mjestoKutije" style="height: 200px">
                        <div class="kutija">
                            <img src="<?php echo $_smarty_tpl->tpl_vars['val']->value->url;?>
"/>
                            <p><?php echo $_smarty_tpl->tpl_vars['naziv_gifa']->value[$_smarty_tpl->tpl_vars['key']->value];?>
</p>
                        </div>
                    <?php } else { ?>
                        <div class="kutija">
                            <img src="<?php echo $_smarty_tpl->tpl_vars['val']->value->url;?>
"/>
                            <p><?php echo $_smarty_tpl->tpl_vars['naziv_gifa']->value[$_smarty_tpl->tpl_vars['key']->value];?>
</p>
                        </div>
                    <?php }?>
                <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
            </div>
        <?php }?>


    <?php }?>
</section>
<?php }
}
