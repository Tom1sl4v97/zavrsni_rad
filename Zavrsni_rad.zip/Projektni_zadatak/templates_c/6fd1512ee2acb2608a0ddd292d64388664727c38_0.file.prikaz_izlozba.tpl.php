<?php
/* Smarty version 3.1.39, created on 2021-08-12 17:00:05
  from 'C:\xampp\htdocs\Projektni_zadatak\templates\Izlozbe\prikaz_izlozba.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_6115377541a6e0_63384667',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6fd1512ee2acb2608a0ddd292d64388664727c38' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Projektni_zadatak\\templates\\Izlozbe\\prikaz_izlozba.tpl',
      1 => 1628608183,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6115377541a6e0_63384667 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_checkPlugins(array(0=>array('file'=>'C:\\xampp\\htdocs\\Projektni_zadatak\\vanjske_biblioteke\\smarty-3.1.39\\libs\\plugins\\modifier.date_format.php','function'=>'smarty_modifier_date_format',),));
?>
<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
CSS/prikaz_forme.css"/>
<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
CSS/popUp_prozor.css"/>
<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
CSS/slider_slike.css"/>
<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
CSS/prikaz_izlozbe.css"/>

<section>
    <div id="slider">
        <figure>
            <img src="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
multimedija/vlak1.jpg" class="prikazSlike">
            <img src="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
multimedija/vlak2.jpg" class="prikazSlike">
            <img src="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
multimedija/vlak3.jpg" class="prikazSlike">
            <img src="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
multimedija/vlak4.jpg" class="prikazSlike">
            <img src="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
multimedija/vlak5.jpg" class="prikazSlike">
        </figure>
    </div>
    <?php if ((isset($_smarty_tpl->tpl_vars['izlozba']->value))) {?>
        <div id="prikazIzlozbe">
            <br><br>
            <h2>
                Dostupne izložbe:
            </h2>
            <br>
            <div class="resetka">
                <?php
$__section_i_0_loop = (is_array(@$_loop=$_smarty_tpl->tpl_vars['izlozba']->value) ? count($_loop) : max(0, (int) $_loop));
$__section_i_0_total = $__section_i_0_loop;
$_smarty_tpl->tpl_vars['__smarty_section_i'] = new Smarty_Variable(array());
if ($__section_i_0_total !== 0) {
for ($__section_i_0_iteration = 1, $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] = 0; $__section_i_0_iteration <= $__section_i_0_total; $__section_i_0_iteration++, $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']++){
?>
                    <div style="margin-bottom: 30px">
                        <div class="izlozbaVlakova">
                            <div class="slika">
                                <?php $_smarty_tpl->_assignInScope('nemaSlike', "ne");?>
                                <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['izborSlike']->value, 'val', false, 'key');
$_smarty_tpl->tpl_vars['val']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['key']->value => $_smarty_tpl->tpl_vars['val']->value) {
$_smarty_tpl->tpl_vars['val']->do_else = false;
?>
                                    <?php if ($_smarty_tpl->tpl_vars['izlozba']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->naziv_tematike == $_smarty_tpl->tpl_vars['val']->value) {?>
                                        <img src="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
multimedija/prikazTeme/<?php echo $_smarty_tpl->tpl_vars['key']->value;?>
.jpg" alt="<?php echo $_smarty_tpl->tpl_vars['key']->value;?>
" style="width: 100%;margin: 0; padding: 0;">
                                        <?php $_smarty_tpl->_assignInScope('nemaSlike', "da");?>
                                    <?php }?>
                                <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                                <?php if ($_smarty_tpl->tpl_vars['nemaSlike']->value == "ne") {?>
                                    <img src="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
multimedija/prikazTeme/ostalo.jpg" alt="<?php echo $_smarty_tpl->tpl_vars['izlozba']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->naziv_tematike;?>
" style="width: 100%;margin: 0; padding: 0;">
                                <?php }?>
                            </div>
                            <div class="naslov">
                                <?php echo $_smarty_tpl->tpl_vars['izlozba']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->naziv_tematike;?>

                            </div>
                            <div>
                                <a class="dodaj" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
izlozbe/prikazi_detalje_izlozbe/<?php echo $_smarty_tpl->tpl_vars['izlozba']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->id;?>
">DETALJI IZLOŽBE</a>
                                <div class="podkategorije">
                                    <?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['izlozba']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->datum_pocetka,"Datum početka: %d.%m.%Y.<br><br>Vrijeme početka: %H:%M");?>
<br><br>
                                    Popunjeno: <?php echo $_smarty_tpl->tpl_vars['izlozba']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->trenutni_broj_korisnika;?>
 / <?php echo $_smarty_tpl->tpl_vars['izlozba']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->broj_korisnika;?>
<br><br>
                                    Status: <?php echo $_smarty_tpl->tpl_vars['izlozba']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->status_izlozbe;?>

                                </div>
                            </div>
                        </div>
                    </div>
                <?php
}
}
?>
            </div>
        </div>
    <?php }?>
</section>
<?php }
}
