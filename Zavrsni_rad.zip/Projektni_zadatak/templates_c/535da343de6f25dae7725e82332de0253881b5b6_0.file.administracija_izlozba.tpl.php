<?php
/* Smarty version 3.1.39, created on 2021-08-18 19:04:54
  from 'C:\xampp\htdocs\Projektni_zadatak\templates\Izlozbe\administracija_izlozba.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_611d3db695f0d8_00079083',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '535da343de6f25dae7725e82332de0253881b5b6' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Projektni_zadatak\\templates\\Izlozbe\\administracija_izlozba.tpl',
      1 => 1629306291,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_611d3db695f0d8_00079083 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_checkPlugins(array(0=>array('file'=>'C:\\xampp\\htdocs\\Projektni_zadatak\\vanjske_biblioteke\\smarty-3.1.39\\libs\\plugins\\modifier.date_format.php','function'=>'smarty_modifier_date_format',),));
?>
<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
CSS/prikaz_teblice.css"/>
<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
CSS/prikaz_forme.css"/>
<!-- linkovi za js -->
<?php echo '<script'; ?>
 src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"><?php echo '</script'; ?>
> 
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
javascript/vlakoviAPI.js"><?php echo '</script'; ?>
>
<section>
    <?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
javascript/tablica.js"><?php echo '</script'; ?>
>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.24/css/jquery.dataTables.css">
    <?php echo '<script'; ?>
 type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.js"><?php echo '</script'; ?>
>


    <h2>
        Tematike vlakova:
        <a class="gumbPrijava2" style="float: right" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
izlozbe/prikaz_podataka_tematike/">Dodaj novu tematiku</a>
    </h2>
    <table id="myTable" class="prikazTablice" style="width: 95%;">
        <thead>
            <tr>
                <th>Naziv tematike</th>
                <th>Opis tematike</th>
                <th></th>
                <th></th>
                <th></th>
            </tr>
        </thead>
        <?php if ((isset($_smarty_tpl->tpl_vars['lista_tematike_vlakova']->value))) {?>
            <tbody>
                <?php
$__section_brojac_liste_tematike_0_loop = (is_array(@$_loop=$_smarty_tpl->tpl_vars['lista_tematike_vlakova']->value) ? count($_loop) : max(0, (int) $_loop));
$__section_brojac_liste_tematike_0_total = $__section_brojac_liste_tematike_0_loop;
$_smarty_tpl->tpl_vars['__smarty_section_brojac_liste_tematike'] = new Smarty_Variable(array());
if ($__section_brojac_liste_tematike_0_total !== 0) {
for ($__section_brojac_liste_tematike_0_iteration = 1, $_smarty_tpl->tpl_vars['__smarty_section_brojac_liste_tematike']->value['index'] = 0; $__section_brojac_liste_tematike_0_iteration <= $__section_brojac_liste_tematike_0_total; $__section_brojac_liste_tematike_0_iteration++, $_smarty_tpl->tpl_vars['__smarty_section_brojac_liste_tematike']->value['index']++){
?>
                    <tr>
                        <td><?php echo $_smarty_tpl->tpl_vars['lista_tematike_vlakova']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_brojac_liste_tematike']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_brojac_liste_tematike']->value['index'] : null)]->naziv;?>
</td>
                        <td><?php echo $_smarty_tpl->tpl_vars['lista_tematike_vlakova']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_brojac_liste_tematike']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_brojac_liste_tematike']->value['index'] : null)]->opis;?>
</td>
                        <td>
                            <a class="prikazGumbicaUredivanja" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
izlozbe/prikaz_administracija_izlozba/<?php echo $_smarty_tpl->tpl_vars['lista_tematike_vlakova']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_brojac_liste_tematike']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_brojac_liste_tematike']->value['index'] : null)]->id;?>
">Detalji</a>
                        </td> 
                        <td>
                            <a class="prikazGumbicaUredivanja" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
izlozbe/prikaz_podataka_tematike/<?php echo $_smarty_tpl->tpl_vars['lista_tematike_vlakova']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_brojac_liste_tematike']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_brojac_liste_tematike']->value['index'] : null)]->id;?>
">Uredi</a>
                        </td>
                        <td>
                            <a class="prikazGumbicaUredivanja" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
izlozbe/obrisi_tematiku/<?php echo $_smarty_tpl->tpl_vars['lista_tematike_vlakova']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_brojac_liste_tematike']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_brojac_liste_tematike']->value['index'] : null)]->id;?>
/">Obrisi</a>
                        </td>
                    </tr>
                <?php
}
}
?>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="3">Ukupno tematika vlakova:</td>
                    <td colspan="2"><?php echo (isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['total']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['total'] : null);?>
</td>
                </tr>
            </tfoot>
        </table>
    <?php }?>

    <?php if ((isset($_smarty_tpl->tpl_vars['detalji_tematike']->value))) {?>
        <div id="detaljiZapisa">
            <br><br>
            <table class="prikazTablice" style="width: 95%">
                <caption style="font-size: 24px; padding: 0px 0px 15px 0px;">Detalji odabrane tematike:</caption>
                <thead>
                    <tr>
                        <th>Naziv tematike</th>
                        <th>Opis tematike</th>
                        <th>Kreirao korisnik</th>
                        <th>Datum kreiranja</th>
                        <th>Ažurirao korisnik</th>
                        <th>Datum ažuriranja</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><?php echo $_smarty_tpl->tpl_vars['detalji_tematike']->value->naziv;?>
</td>
                        <td><?php echo $_smarty_tpl->tpl_vars['detalji_tematike']->value->opis;?>
</td>
                        <td><?php echo $_smarty_tpl->tpl_vars['detalji_tematike']->value->korisnik_kreiranja;?>
</td>
                        <td><?php echo $_smarty_tpl->tpl_vars['detalji_tematike']->value->datum_kreiranja;?>
</td>
                        <td><?php echo $_smarty_tpl->tpl_vars['detalji_tematike']->value->korisnik_azuriranja;?>
</td>
                        <td><?php echo $_smarty_tpl->tpl_vars['detalji_tematike']->value->datum_azuriranja;?>
</td>
                    </tr>
                </tbody>
            </table>
            <br><br>
        </div>
    <?php }?>
    <br><br>
    <h2>
        <a>Moderatori</a>
        <a class="gumbPrijava2" style="float: right" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
izlozbe/prikaz_dodijele_moderatora/">Dodijeli novog moderatora</a>
    </h2>
    <?php if ((isset($_smarty_tpl->tpl_vars['popis_moderatora']->value))) {?>
        <table id="myTable2" class="prikazTablice" style="width: 95%;">
            <thead>
                <tr>
                    <th>Administrator</th>
                    <th>Moderator</th>
                    <th>Tematika</th>
                    <th>Vazi od</th>
                    <th>Vazi do</th>
                    <th></th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php
$__section_brojac_popisa_moderatora_1_loop = (is_array(@$_loop=$_smarty_tpl->tpl_vars['popis_moderatora']->value) ? count($_loop) : max(0, (int) $_loop));
$_smarty_tpl->tpl_vars['__smarty_section_brojac_popisa_moderatora'] = new Smarty_Variable(array('total' => $__section_brojac_popisa_moderatora_1_loop));
if ($_smarty_tpl->tpl_vars['__smarty_section_brojac_popisa_moderatora']->value['total'] !== 0) {
for ($__section_brojac_popisa_moderatora_1_iteration = 1, $_smarty_tpl->tpl_vars['__smarty_section_brojac_popisa_moderatora']->value['index'] = 0; $__section_brojac_popisa_moderatora_1_iteration <= $_smarty_tpl->tpl_vars['__smarty_section_brojac_popisa_moderatora']->value['total']; $__section_brojac_popisa_moderatora_1_iteration++, $_smarty_tpl->tpl_vars['__smarty_section_brojac_popisa_moderatora']->value['index']++){
?>
                    <tr>
                        <td><?php echo $_smarty_tpl->tpl_vars['popis_moderatora']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_brojac_popisa_moderatora']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_brojac_popisa_moderatora']->value['index'] : null)]->korisnicko_ime_administratora;?>
</td>
                        <td><?php echo $_smarty_tpl->tpl_vars['popis_moderatora']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_brojac_popisa_moderatora']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_brojac_popisa_moderatora']->value['index'] : null)]->korisnicko_ime_moderatora;?>
</td>
                        <td><?php echo $_smarty_tpl->tpl_vars['popis_moderatora']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_brojac_popisa_moderatora']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_brojac_popisa_moderatora']->value['index'] : null)]->naziv_tematike;?>
</td>
                        <td><?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['popis_moderatora']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_brojac_popisa_moderatora']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_brojac_popisa_moderatora']->value['index'] : null)]->vazi_od,"d.m.Y.");?>
</td>
                        <td>
                            <?php if ($_smarty_tpl->tpl_vars['popis_moderatora']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_brojac_popisa_moderatora']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_brojac_popisa_moderatora']->value['index'] : null)]->vazi_do != "NULL") {?>
                                <?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['popis_moderatora']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_brojac_popisa_moderatora']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_brojac_popisa_moderatora']->value['index'] : null)]->vazi_do,"d.m.Y.");?>

                            <?php }?>
                        </td>
                        <td>
                            <a class="prikazGumbicaUredivanja" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
izlozbe/prikaz_dodijele_moderatora/<?php echo $_smarty_tpl->tpl_vars['popis_moderatora']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_brojac_popisa_moderatora']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_brojac_popisa_moderatora']->value['index'] : null)]->id;?>
">Uredi</a>
                        </td>
                        <td>
                            <a class="prikazGumbicaUredivanja" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
izlozbe/obrisi_zapis_tablice_moderatora/<?php echo $_smarty_tpl->tpl_vars['popis_moderatora']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_brojac_popisa_moderatora']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_brojac_popisa_moderatora']->value['index'] : null)]->id;?>
">Obrisi</a>
                        </td>
                    </tr>
                <?php
}
}
?>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="4">Ukupni broj moderatora tematike vlakova:</td>
                    <td colspan="3"><?php echo (isset($_smarty_tpl->tpl_vars['__smarty_section_brojac_popisa_moderatora']->value['total']) ? $_smarty_tpl->tpl_vars['__smarty_section_brojac_popisa_moderatora']->value['total'] : null);?>
</td>
                </tr>
            </tfoot>
        </table>
    <?php }?>

</section>
<?php }
}
