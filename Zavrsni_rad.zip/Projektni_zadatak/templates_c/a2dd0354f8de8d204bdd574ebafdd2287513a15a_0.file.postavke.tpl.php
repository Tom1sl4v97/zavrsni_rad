<?php
/* Smarty version 3.1.39, created on 2021-08-18 21:21:32
  from 'C:\xampp\htdocs\Projektni_zadatak\templates\Upravljanje\postavke.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_611d5dbc29afe5_47129688',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a2dd0354f8de8d204bdd574ebafdd2287513a15a' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Projektni_zadatak\\templates\\Upravljanje\\postavke.tpl',
      1 => 1629314488,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_611d5dbc29afe5_47129688 (Smarty_Internal_Template $_smarty_tpl) {
?><link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
CSS/prikaz_izlozbe.css"/>
<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
CSS/prikaz_forme.css"/>
<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
CSS/prikaz_teblice.css"/>

<?php echo '<script'; ?>
 src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"><?php echo '</script'; ?>
> 
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
javascript/tablica.js"><?php echo '</script'; ?>
>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.24/css/jquery.dataTables.css">
<?php echo '<script'; ?>
 type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.js"><?php echo '</script'; ?>
>
<section>
    <h2>
        Prikaz postavki stranice
    </h2>
    <br>
    <div class="resetka">
        <div style="margin-bottom: 25px; min-width: 100%">
            <div class="izlozbaVlakova">
                <div class="naslov">
                    <p>
                        Izmjena trajanja sesije
                    </p>
                </div>
                <div>
                    <div class="podkategorije">
                        <form class="prikazForme" method="post" name="promjenaTrajanjaSesije" action="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
upravljanje/azuriraj_trajanje_sesije/">
                            <p>
                                Trenutno: <?php echo $_smarty_tpl->tpl_vars['trenutni_zapis_sesije']->value;?>
 h
                            </p>
                            <input style="width: 97%; height: 25px" type="time" step="1" name="izmjeniSesiju"><br><br>
                            <input class="dodaj" type="submit" value="Spremi">
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div style="margin-bottom: 25px; min-width: 100%">
            <div class="izlozbaVlakova">
                <div class="naslov">
                    <p>
                        Izmjena virtualnog vrijemena<br>(sati)
                    </p>
                </div>
                <div>
                    <div class="podkategorije">
                        <form class="prikazForme" method="post" name="promjenaTrajanjaSesije" action="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
upravljanje/azuriraj_virtualno_vrijeme/">
                            <p>
                                Trenutno: <?php echo $_smarty_tpl->tpl_vars['trenutni_zapis_virtualnog_vremena']->value;?>
 h razlike
                            </p>
                            <b><a target="_blank" href="http://barka.foi.hr/WebDiP/pomak_vremena/vrijeme.html" 
                                  style="text-decoration: none;">
                                    Postavi virtualno vrijeme
                                </a>
                            </b>
                            <br><br>
                            <input class="dodaj" type="submit" value="Spremi">
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div style="margin-bottom: 25px; min-width: 100%">
            <div class="izlozbaVlakova">
                <div class="naslov">
                    <p>
                        Izmjena trajanja kolacica<br>(dani)
                    </p>
                </div>
                <div>
                    <div class="podkategorije">
                        <form class="prikazForme" method="post" name="promjenaTrajanjaKolacica" 
                              action="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
upravljanje/azuriraj_trajanje_kolacica/">
                            <p>
                                Trenutno: <?php echo $_smarty_tpl->tpl_vars['trenutni_zapis_kolacica']->value;?>
 dan/a
                            </p>
                            <input style="width: 97%; height: 25px" type="text" name="novoTrajanjeKolacica"><br><br>
                            <input class="dodaj" type="submit" value="Spremi">
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div style="margin-bottom: 25px; min-width: 100%">
            <div class="izlozbaVlakova">
                <div class="naslov">
                    <p>
                        Resetiranje uvjeta korištenja<br>
                        svih korisnika (dani)
                    </p>
                </div>
                <div>
                    <div class="podkategorije">
                        <form class="prikazForme" method="post" action="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
upravljanje/resetiraj_uvjete_koristenja/">
                            <input class="dodaj" type="submit" value="Resetiraj uvjete" style="margin-top: 10px">
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div style="margin-bottom: 25px; min-width: 100%">
            <div class="izlozbaVlakova">
                <div class="naslov">
                    <p>
                        Napravi sigurosnu kopiju<br>svih vlakova i materijala
                    </p>
                </div>
                <div>
                    <div class="podkategorije">
                        <form class="prikazForme" method="post" action="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
upravljanje/kreiraj_sigurnosnu_kopiju/">
                            <input class="dodaj" type="submit" value="Napravi sigurosnu kopiju" style="margin-top: 10px">
                        </form>
                    </div>
                    <br><br>
                </div>
            </div>
        </div>
        <div style="margin-bottom: 25px; min-width: 100%">
            <div class="izlozbaVlakova">
                <div class="naslov">
                    <p>
                        Postavi podatke iz sigurosne<br>kopije svi vlakova i materijala
                    </p>
                </div>
                <div>
                    <div class="podkategorije">
                        <form class="prikazForme" method="post" action="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
upravljanje/vrati_sigurnosnu_kopiju/">
                            <input class="dodaj" type="submit" value="Postavi podatke iz kopije" style="margin-top: 10px">
                        </form>
                    </div>
                    <br><br>
                </div>
            </div>
        </div>
    </div>

    <?php if ((isset($_smarty_tpl->tpl_vars['popis_korisnika']->value))) {?>

        <br><br>
        <h2>
            Lista korisničkih računa
        </h2>
        <table id="myTable" class="prikazTablice" style="width: 95%;">
            <thead>
                <tr>
                    <th>Ime</th>
                    <th>Prezime</th>
                    <th>Korisničko ime</th>
                    <th>E-mail</th>
                    <th>Uloga</th>
                    <th>Gumb</th>
                </tr>
            </thead>
            <?php
$__section_i_0_loop = (is_array(@$_loop=$_smarty_tpl->tpl_vars['popis_korisnika']->value) ? count($_loop) : max(0, (int) $_loop));
$_smarty_tpl->tpl_vars['__smarty_section_i'] = new Smarty_Variable(array('total' => $__section_i_0_loop));
if ($_smarty_tpl->tpl_vars['__smarty_section_i']->value['total'] !== 0) {
for ($__section_i_0_iteration = 1, $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] = 0; $__section_i_0_iteration <= $_smarty_tpl->tpl_vars['__smarty_section_i']->value['total']; $__section_i_0_iteration++, $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']++){
?>
                <tr>
                    <td><?php echo $_smarty_tpl->tpl_vars['popis_korisnika']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->ime;?>
</td>
                    <td><?php echo $_smarty_tpl->tpl_vars['popis_korisnika']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->prezime;?>
</td>
                    <td><?php echo $_smarty_tpl->tpl_vars['popis_korisnika']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->korisnicko_ime;?>
</td>
                    <td><?php echo $_smarty_tpl->tpl_vars['popis_korisnika']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->email;?>
</td>
                    <td><?php echo $_smarty_tpl->tpl_vars['popis_korisnika']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->naziv_uloge;?>
</td>
                    <td>

                        <?php if ($_smarty_tpl->tpl_vars['popis_korisnika']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->broj_neuspijesnih_prijava < 3) {?>
                            <a class="dodaj" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
upravljanje/blokiraj_korisnika/<?php echo $_smarty_tpl->tpl_vars['popis_korisnika']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->id;?>
/" 
                               style="background-color: #D68B6F;color: black">Blokiraj</a>
                        <?php } else { ?>
                            <a class="dodaj" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
upravljanje/de_blokiraj_korisnika/<?php echo $_smarty_tpl->tpl_vars['popis_korisnika']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->id;?>
/" 
                               style="background-color: #93B080;color:black">Prihvati</a>
                        <?php }?>
                    </td>
                </tr>
            <?php
}
}
?>
            <tfoot>
                <tr>
                    <td colspan="4">Ukupno tematika vlakova:</td>
                    <td colspan="2"><?php echo (isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['total']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['total'] : null);?>
</td>
                </tr>
            </tfoot>
        </table>
    <?php }?>

    <br><br>
    <h2>
        Zapis dnevnika korištenja
    </h2>
    <div class="podkategorije">
        <form class="prikazForme" method="post" action="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
upravljanje/prikazi_postavke_stranice/">
            <label for="pocetniDatum">Pretraži dnevnik od datuma:</label><br>
            <input type="date" id="pocetniDatum" name="pocetniDatum" class="okvirForme2" style="width: 200px; height: 4px"><br><br>

            <label for="zavrsniDatum">Pretraži dnevnik do datuma:</label><br>
            <input type="date" id="zavrsniDatum" name="zavrsniDatum" class="okvirForme2" style="width: 200px; height: 4px"><br><br>

            <input class="gumbPrijava" type="submit" value="Pretraži"><br><br>
        </form>
    </div>

    <table id="myTable2" class="prikazTablice" style="width: 95%;">
        <thead>
            <tr>
                <th>ID dnevnika</th>
                <th>Korisnik</th>
                <th>E-mail</th>
                <th>Stranica</th>
                <th>Upit</th>
                <th>Datum</th>
                <th>Tip radnje</th>
            </tr>
        </thead>

        <?php
$__section_i_1_loop = (is_array(@$_loop=$_smarty_tpl->tpl_vars['dnevnik_koristenja_stranice']->value) ? count($_loop) : max(0, (int) $_loop));
$_smarty_tpl->tpl_vars['__smarty_section_i'] = new Smarty_Variable(array('total' => $__section_i_1_loop));
if ($_smarty_tpl->tpl_vars['__smarty_section_i']->value['total'] !== 0) {
for ($__section_i_1_iteration = 1, $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] = 0; $__section_i_1_iteration <= $_smarty_tpl->tpl_vars['__smarty_section_i']->value['total']; $__section_i_1_iteration++, $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']++){
?>
            <tr>
                <td><?php echo $_smarty_tpl->tpl_vars['dnevnik_koristenja_stranice']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->id;?>
</td>
                <td><?php echo $_smarty_tpl->tpl_vars['dnevnik_koristenja_stranice']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->ime;?>
 <?php echo $_smarty_tpl->tpl_vars['dnevnik_koristenja_stranice']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->prezime;?>
 <?php echo $_smarty_tpl->tpl_vars['dnevnik_koristenja_stranice']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->korisnicko_ime;?>
</td>
                <td><?php echo $_smarty_tpl->tpl_vars['dnevnik_koristenja_stranice']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->email;?>
</td>
                <td><?php echo $_smarty_tpl->tpl_vars['urlStranica']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)];?>
</td>
                <td><?php echo $_smarty_tpl->tpl_vars['dnevnik_koristenja_stranice']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->upit;?>
</td>
                <td><?php echo $_smarty_tpl->tpl_vars['dnevnik_koristenja_stranice']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->datum_pristupa;?>
</td>
                <td><?php echo $_smarty_tpl->tpl_vars['dnevnik_koristenja_stranice']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->tip_dnevnika_opis;?>
</td>
            </tr>
        <?php
}
}
?>
        <tfoot>
            <tr>
                <td colspan="6">Ukupan broj zapisa:</td>
                <td><?php echo (isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['total']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['total'] : null);?>
</td>
            </tr>
        </tfoot>
    </table>

</section>
<?php }
}
