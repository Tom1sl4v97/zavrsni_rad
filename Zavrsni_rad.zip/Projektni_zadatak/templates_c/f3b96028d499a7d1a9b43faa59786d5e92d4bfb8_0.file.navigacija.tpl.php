<?php
/* Smarty version 3.1.39, created on 2021-08-18 21:17:27
  from 'C:\xampp\htdocs\Projektni_zadatak\templates\dijeljeno\navigacija.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_611d5cc7cfb678_76410831',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f3b96028d499a7d1a9b43faa59786d5e92d4bfb8' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Projektni_zadatak\\templates\\dijeljeno\\navigacija.tpl',
      1 => 1629314241,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_611d5cc7cfb678_76410831 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html lang="hr">
    <head>
        <title><?php echo $_smarty_tpl->tpl_vars['naslov_stranice']->value;?>
</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="title" content="<?php echo $_smarty_tpl->tpl_vars['naslov_stranice']->value;?>
">
        <meta name="author" content="Tomislav Tomiek">
        <meta name="description" content="<?php echo $_smarty_tpl->tpl_vars['opis_stranice']->value;?>
">
        <meta name="keywords" content="">
        <link rel="icon" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
multimedija/iconica.png">

        <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
CSS/ttomiek.css"/>
        <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
CSS/ttomiek_accesibility.css" 
              <?php if (!(isset($_SESSION['dizajn']))) {?>
                  disabled
              <?php } else { ?>
                  <?php echo $_SESSION['dizajn'];?>

              <?php }?>
              />
        <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
CSS/darkmode.css" 
              <?php if (!(isset($_SESSION['darkmode']))) {?>
                  disabled
              <?php } else { ?>
                  <?php echo $_SESSION['darkmode'];?>

              <?php }?>
              />
    </head>
    <div id="kutijaDizajnaAccessibility">
        <form style="border: none;background-color: transparent;" action="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
upravljanje/postavi_dizajn/">
            <button type="submit" name="promjenaDizajna" class="slikaGumbaAccessibility" value="disable"></button>
        </form>
    </div>
    <div id="kutijaDizajnaDarkMode">
        <form style="border: none;background-color: transparent;" action="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
upravljanje/postavi_dark_mode/">
            <button class="slikaGumbaDarkMode" type="submit"></button>
        </form>
    </div>
    <body>
        <header>
            <h1> 
                <img src="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
multimedija/train.png" alt="vlak" width="70" style="float:left;margin:0px;padding: 0px" />
                <a href="#sekcija_sadržaj"><?php echo $_smarty_tpl->tpl_vars['naslov_stranice']->value;?>
</a>
            </h1>
        </header>
        <nav>
            <ul>
                <li><a href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
pocetna_stranica/index/">Početna stranica</a></li>
                <li><a href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
pocetna_stranica/autor_stranice/">Autor</a></li>

                <?php if (!(isset($_SESSION['uloga']))) {?>
                    <li><a href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
korisnici/podaci_na_prijavu/">Prijava</a></li>
                    <?php }?>

                <?php if ((isset($_SESSION['uloga'])) && $_SESSION['uloga'] < 4) {?>
                    <li><a href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
izlozbe/prikazi_izlozbe/">Izložbe</a></li>
                    <li><a href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
vlakovi/prikaz_vlakova_korisnika/">Vaši vlakovi</a></li>
                    <?php }?>

                <?php if ((isset($_SESSION['uloga'])) && $_SESSION['uloga'] < 3) {?>
                    <li><a href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
izlozbe/prikaz_uredivanje_izlozba/">Uređivanje izložba</a></li>
                    <li><a href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
Vlakovi/prikaz_prijava/">Pregled prijava</a></li>
                    <?php }?>

                <?php if ((isset($_SESSION['uloga'])) && $_SESSION['uloga'] == 1) {?>
                    <li><a href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
izlozbe/prikaz_administracija_izlozba/">Administracija izložba</a></li>
                    <li><a href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
upravljanje/prikazi_postavke_stranice/">Postavke</a></li>
                    <?php }?>

                <?php if ((isset($_SESSION['uloga'])) && $_SESSION['uloga'] < 4) {?>
                    <li><a href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
korisnici/odjava/">Odjava</a></li>
                    <?php }?>
            </ul>
        </nav>
<?php }
}
