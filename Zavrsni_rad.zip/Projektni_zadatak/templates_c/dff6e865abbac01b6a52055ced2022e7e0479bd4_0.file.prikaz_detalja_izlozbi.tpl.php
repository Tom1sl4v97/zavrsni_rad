<?php
/* Smarty version 3.1.39, created on 2021-08-27 13:51:56
  from 'C:\xampp\htdocs\Projektni_zadatak\templates\Izlozbe\prikaz_detalja_izlozbi.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_6128d1dc3e6e35_16903465',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'dff6e865abbac01b6a52055ced2022e7e0479bd4' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Projektni_zadatak\\templates\\Izlozbe\\prikaz_detalja_izlozbi.tpl',
      1 => 1629886240,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6128d1dc3e6e35_16903465 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_checkPlugins(array(0=>array('file'=>'C:\\xampp\\htdocs\\Projektni_zadatak\\vanjske_biblioteke\\smarty-3.1.39\\libs\\plugins\\modifier.date_format.php','function'=>'smarty_modifier_date_format',),));
?>
<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
CSS/prikaz_forme.css"/>
<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
CSS/popUp_prozor.css"/>
<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
CSS/slider_slike.css"/>
<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
CSS/prikaz_izlozbe.css"/>

<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
javascript/prikaz_kontrola_kod_izlozbi.js"><?php echo '</script'; ?>
>

<section>
    <div class="popUp" id="dodaj_vlak">
        <div class="popUpPozadina">
            <div id="odustani" class="odustani"> X </div>
            <h2 style="padding: 0">Odaberite željeni vlak za odabranu izložbu:</h2>
            <h2 id="textIzlozbe" style="padding: 0"></h2>
            <br>
            <div id="bezVlakova"></div>
            <?php if (!empty($_smarty_tpl->tpl_vars['slobodni_vlakovi_korisnika']->value[0])) {?>
                <form method="post" class="popUpForma" action="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
izlozbe/prijavi_vlak_na_izlozbu/<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
">
                    <select name="odabirVlakaZaPrijavu" class="prikazDropDown">
                        <option value="0" class="prikazDropDown">Odaberite</option>
                        <?php
$__section_i_0_loop = (is_array(@$_loop=$_smarty_tpl->tpl_vars['slobodni_vlakovi_korisnika']->value) ? count($_loop) : max(0, (int) $_loop));
$__section_i_0_total = $__section_i_0_loop;
$_smarty_tpl->tpl_vars['__smarty_section_i'] = new Smarty_Variable(array());
if ($__section_i_0_total !== 0) {
for ($__section_i_0_iteration = 1, $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] = 0; $__section_i_0_iteration <= $__section_i_0_total; $__section_i_0_iteration++, $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']++){
?>
                            <option value="<?php echo $_smarty_tpl->tpl_vars['slobodni_vlakovi_korisnika']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->id;?>
" class="prikazDropDown">
                                <?php echo $_smarty_tpl->tpl_vars['slobodni_vlakovi_korisnika']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->naziv;?>

                            </option>
                        <?php
}
}
?>
                    </select>
                    <br><br>
                    <button type="submit" class="gumbPrijava">Prijavi vlak</button>
                </form>
            <?php } else { ?>
                <h4>Dodali ste već sve vaše vlakove na izložbu ili nemate kreiranje vlastite vlakove.</h4>
            <?php }?>
        </div>
    </div> 

    <div id="detaljiIzlozbe">
        <h2 class="naslovPravi" id="naslov"><?php echo $_smarty_tpl->tpl_vars['izlozba']->value->naziv_tematike;?>
</h2>
        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['izborSlike']->value, 'val', false, 'key');
$_smarty_tpl->tpl_vars['val']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['key']->value => $_smarty_tpl->tpl_vars['val']->value) {
$_smarty_tpl->tpl_vars['val']->do_else = false;
?>
            <?php if ($_smarty_tpl->tpl_vars['izlozba']->value->naziv_tematike == $_smarty_tpl->tpl_vars['val']->value) {?>
                <img src="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
multimedija/prikazTeme/<?php echo $_smarty_tpl->tpl_vars['key']->value;?>
.jpg" class="slika_izlozbe">
                <?php $_smarty_tpl->_assignInScope('nemaSlike', "da");?>
            <?php }?>
        <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
        <?php if ($_smarty_tpl->tpl_vars['nemaSlike']->value == "ne") {?>
            <img src="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
multimedija/prikazTeme/ostalo.jpg" alt="<?php echo $_smarty_tpl->tpl_vars['izlozba']->value->naziv_tematike;?>
" class="slika_izlozbe">
        <?php }?>

        <img src="" style="width: 55%;margin: 0; padding-top:  30px;float: right" id="slikaNaslova">
        <br><br>
        <h2>Osnovne informacije o izložbi:</h2>
        <br>
        <h3>Datum početka izložbe:</h3>
        <p class="prikaz_informacija"><?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['izlozba']->value->datum_pocetka,"%d.%m.%Y.");?>
</p>
        <h3>Vrijeme početka:</h3>
        <p class="prikaz_informacija"><?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['izlozba']->value->datum_pocetka,"%H:%M");?>
</p>
        <h3>Popunjenost izložbe:</h3>
        <p class="prikaz_informacija"><?php echo $_smarty_tpl->tpl_vars['izlozba']->value->trenutni_broj_korisnika;?>
 / <?php echo $_smarty_tpl->tpl_vars['izlozba']->value->broj_korisnika;?>
</p>
        <h3>Kratki opis o izložbi:</h3>
        <p class="prikaz_informacija"><?php echo $_smarty_tpl->tpl_vars['izlozba']->value->opis_tematike;?>
</p>
        <br>

        <a class="gumbPrijava2" style="margin-left: 2%" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
izlozbe/prikazi_izlozbe/">Vrati se</a>
        <?php if ($_smarty_tpl->tpl_vars['izlozba']->value->status_izlozbe === "Otvorene prijave") {?>
            <a class="gumbPrijava2" onclick="odabir_vlaka('<?php echo $_smarty_tpl->tpl_vars['izlozba']->value->naziv_tematike;?>
')">Prijavi svoj vlak</a>
        <?php }?>

        <br><br><br><br>


        <?php
$__section_i_1_loop = (is_array(@$_loop=$_smarty_tpl->tpl_vars['popis_prijavljenih_korisnika']->value) ? count($_loop) : max(0, (int) $_loop));
$__section_i_1_total = $__section_i_1_loop;
$_smarty_tpl->tpl_vars['__smarty_section_i'] = new Smarty_Variable(array());
if ($__section_i_1_total !== 0) {
for ($__section_i_1_iteration = 1, $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] = 0; $__section_i_1_iteration <= $__section_i_1_total; $__section_i_1_iteration++, $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']++){
?>
            <div class="prikazKorisnika">
                <div class="kutija">
                    <img src="<?php echo $_smarty_tpl->tpl_vars['popis_prijavljenih_korisnika']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->url_slike;?>
" alt="<?php echo $_smarty_tpl->tpl_vars['popis_prijavljenih_korisnika']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->naziv;?>
" class="
                         <?php if (((isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)%2) == 0) {?>
                             slikaKorisnikaLijeva
                         <?php } else { ?>
                             slikaKorisnikaDesna
                         <?php }?>">
                    <div class="
                         <?php if (((isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)%2) == 0) {?>
                             prikazTekstaLijevi
                         <?php } else { ?>
                             prikazTekstaDesni
                         <?php }?>">
                        <a><b>Informacije o vlasniku:</b> <?php echo $_smarty_tpl->tpl_vars['popis_prijavljenih_korisnika']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->ime_korisnika;?>
 <?php echo $_smarty_tpl->tpl_vars['popis_prijavljenih_korisnika']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->prezime_korisnika;?>
 - <?php echo $_smarty_tpl->tpl_vars['popis_prijavljenih_korisnika']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->korisnicko_ime;?>
 </a>
                        <br><br>
                        <a><b>Naziv vlaka:</b> <?php echo $_smarty_tpl->tpl_vars['popis_prijavljenih_korisnika']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->naziv;?>
</a>
                        <br><br>
                        <a><b>Maksimalna brzina:</b>  <?php echo $_smarty_tpl->tpl_vars['popis_prijavljenih_korisnika']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->max_brzina;?>
 &nbsp;&nbsp;&nbsp;&nbsp;<b>Broj sjedala vlaka:</b> <?php echo $_smarty_tpl->tpl_vars['popis_prijavljenih_korisnika']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->broj_sjedala;?>
</a>
                        <br><br>
                        <a><b>Vrsta pogona:</b> <?php echo $_smarty_tpl->tpl_vars['popis_prijavljenih_korisnika']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->naziv_pogona;?>

                            <br><br><br>
                            <?php if ($_smarty_tpl->tpl_vars['popis_prijavljenih_korisnika']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->status === "Otvorene prijave" && $_smarty_tpl->tpl_vars['popis_prijavljenih_korisnika']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->korisnicko_ime === $_smarty_tpl->tpl_vars['korisnicko_ime']->value) {?>
                                <a class="gumbPrijava2" onclick="dodaj_materijale(<?php echo (isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null);?>
)">Dodaj materijale</a>
                                <a class="gumbPrijava2" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
izlozbe/obrisi_vlak_sa_izlozbe/<?php echo $_smarty_tpl->tpl_vars['popis_prijavljenih_korisnika']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->id;?>
">Obrisi vlak</a>
                            <?php }?>
                            <?php if ($_smarty_tpl->tpl_vars['popis_prijavljenih_korisnika']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->status === "Otvoreno glasovanje" && $_smarty_tpl->tpl_vars['popis_prijavljenih_korisnika']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->korisnicko_ime !== $_smarty_tpl->tpl_vars['korisnicko_ime']->value) {?>
                                <a class="gumbPrijava2" onclick="otvori_glasovanje(<?php echo (isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null);?>
)">Glasaj</a>
                            <?php }?>
                            <a class="gumbPrijava2" style="float: right;" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
vlakovi/prikaz_detalja_prijavljenog_vlaka/<?php echo $_smarty_tpl->tpl_vars['popis_prijavljenih_korisnika']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->id;?>
">Detalji</a>
                        </a>
                    </div>
                    <br><br>
                </div>
            </div>

            <div class="popUp" id="glasaj<?php echo (isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null);?>
">
                <div class="popUpPozadina">
                    <div onclick="zatvori_pop_up_glasovanja(<?php echo (isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null);?>
)" class="odustani"> X </div>
                    <h2 style="padding: 0; margin: 0;">Ocijeni korisnika:</h2>
                    <br>
                    <form method="post" class="popUpForma" action="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
izlozbe/ocjeni_prijavljenog_vlaka/<?php echo $_smarty_tpl->tpl_vars['popis_prijavljenih_korisnika']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->id;?>
">
                        <label>Ocjena (1 - 10):</label>
                        <input class="okvirForme" type="number" name="ocjena" min="1" max="10">
                        <br><br>
                        <label>Komentar:</label>
                        <input class="okvirForme" type="text" name="komentar">
                        <br><br>
                        <button type="submit" class="gumbPrijava">Glasaj</button>
                    </form>
                </div>
            </div>

            <div class="popUp" id="dodaj_materijale<?php echo (isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null);?>
">
                <div class="popUpPozadina">
                    <div onclick="zatvori_pop_up_materijala(<?php echo (isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null);?>
)" class="odustani"> X </div>
                    <h2 style="padding: 0">Dodajte željene materijale:</h2>
                    <h2 id="textIzlozbe" style="padding: 0"></h2>
                    <br>
                    <form class="popUpForma" enctype="multipart/form-data" action="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
vlakovi/ucitaj_materijale_korisnika_na_izlozbu/<?php echo $_smarty_tpl->tpl_vars['popis_prijavljenih_korisnika']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->id;?>
/" method="post">
                        <label for="odabirMaterijala">Odaberite vrstu materijala:</label><br>
                        <select name="odabirMaterijala" id="odabirMaterijala" class="prikazDropDown">
                            <option value="0" class="prikazDropDown">Odaberite</option>
                            <?php
$__section_brojac_2_loop = (is_array(@$_loop=$_smarty_tpl->tpl_vars['vrsta_materijala']->value) ? count($_loop) : max(0, (int) $_loop));
$__section_brojac_2_total = $__section_brojac_2_loop;
$_smarty_tpl->tpl_vars['__smarty_section_brojac'] = new Smarty_Variable(array());
if ($__section_brojac_2_total !== 0) {
for ($__section_brojac_2_iteration = 1, $_smarty_tpl->tpl_vars['__smarty_section_brojac']->value['index'] = 0; $__section_brojac_2_iteration <= $__section_brojac_2_total; $__section_brojac_2_iteration++, $_smarty_tpl->tpl_vars['__smarty_section_brojac']->value['index']++){
?>
                                <option value="<?php echo $_smarty_tpl->tpl_vars['vrsta_materijala']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_brojac']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_brojac']->value['index'] : null)]->id;?>
" class="prikazDropDown">
                                    <?php echo $_smarty_tpl->tpl_vars['vrsta_materijala']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_brojac']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_brojac']->value['index'] : null)]->format;?>

                                </option>
                            <?php
}
}
?>
                        </select>
                        <br><br>
                        <input type="hidden" name="MAX_FILE_SIZE" value="3000000000" />
                        <input name="upload[]" type="file" multiple="multiple" class="prikazDropDown"/><br><br>

                        <button type="submit" class="gumbPrijava">Pošalji</button>
                    </form>

                </div>
            </div>           

        <?php
}
}
?>
    </div>
</section>
<?php }
}
