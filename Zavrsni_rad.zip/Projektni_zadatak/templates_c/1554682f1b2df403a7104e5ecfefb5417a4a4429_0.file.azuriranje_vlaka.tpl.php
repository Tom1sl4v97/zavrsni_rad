<?php
/* Smarty version 3.1.39, created on 2021-08-18 21:44:20
  from 'C:\xampp\htdocs\Projektni_zadatak\templates\Vlakovi\azuriranje_vlaka.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_611d6314459d14_46099563',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1554682f1b2df403a7104e5ecfefb5417a4a4429' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Projektni_zadatak\\templates\\Vlakovi\\azuriranje_vlaka.tpl',
      1 => 1629315859,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_611d6314459d14_46099563 (Smarty_Internal_Template $_smarty_tpl) {
?><link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
/CSS/prikaz_forme.css"/>
<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
/CSS/prikaz_teblice.css"/>

<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
/javascript/dodavanje_novog_pogona_vlaka.js" ><?php echo '</script'; ?>
>
<section id="sadrzajObrasca">
    <div>
        <br>
        <form id ="form1" method="post" name="dodavanjeNovogVlaka" action="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
vlakovi/azuriraj_vlak_korisnika/<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
" enctype="multipart/from-data">
            
            <br>
            <div id="informacijaVlaka">
                <label for="nazivVlaka">Naziv vlaka: </label>
                <input class="okvirForme" type="text" id="nazivVlaka" name="nazivVlaka"
                       <?php if ((isset($_smarty_tpl->tpl_vars['podaci_vlaka']->value))) {?>
                           value="<?php echo $_smarty_tpl->tpl_vars['podaci_vlaka']->value->naziv;?>
"
                       <?php }?>
                       ><br><br>

                <label for="maxBrzina">Maksimalna brzina vlaka (km/h): </label>
                <input class="okvirForme" type="text" id="maxBrzina" name="maxBrzina" 
                       <?php if ((isset($_smarty_tpl->tpl_vars['podaci_vlaka']->value))) {?>
                           value="<?php echo $_smarty_tpl->tpl_vars['podaci_vlaka']->value->max_brzina;?>
"
                       <?php }?>
                       ><br><br>

                <label for="brojSjedala">Broj sjedala vlaka: </label>
                <input class="okvirForme" type="text" id="brojSjedala" name="brojSjedala" 
                       <?php if ((isset($_smarty_tpl->tpl_vars['podaci_vlaka']->value))) {?>
                           value="<?php echo $_smarty_tpl->tpl_vars['podaci_vlaka']->value->broj_sjedala;?>
"
                       <?php }?>
                       ><br><br>

                <label for="opisVlaka">Opis vlaka: </label>
                <input class="okvirForme" type="text" id="opisVlaka" name="opisVlaka" 
                       <?php if ((isset($_smarty_tpl->tpl_vars['podaci_vlaka']->value))) {?>
                           value="<?php echo $_smarty_tpl->tpl_vars['podaci_vlaka']->value->opis;?>
"
                       <?php }?>
                       ><br><br>

                <label for="vrstaPognona">Vrsta pogona:</label><br>
                <select name="vrstaPognona" id="vrstaPognona" class="prikazDropDown">
                    <option value="0" class="prikazDropDown">Odaberite</option>
                    <?php
$__section_i_0_loop = (is_array(@$_loop=$_smarty_tpl->tpl_vars['vrsta_pogona']->value) ? count($_loop) : max(0, (int) $_loop));
$__section_i_0_total = $__section_i_0_loop;
$_smarty_tpl->tpl_vars['__smarty_section_i'] = new Smarty_Variable(array());
if ($__section_i_0_total !== 0) {
for ($__section_i_0_iteration = 1, $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] = 0; $__section_i_0_iteration <= $__section_i_0_total; $__section_i_0_iteration++, $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']++){
?>
                        <option value="<?php echo $_smarty_tpl->tpl_vars['vrsta_pogona']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->id;?>
" class="prikazDropDown"
                                <?php if ((isset($_smarty_tpl->tpl_vars['podaci_vlaka']->value)) && $_smarty_tpl->tpl_vars['podaci_vlaka']->value->vrsta_pogona_id == $_smarty_tpl->tpl_vars['vrsta_pogona']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->id) {?>
                                    selected
                                <?php }?>
                                >
                            <?php echo $_smarty_tpl->tpl_vars['vrsta_pogona']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->naziv_pogona;?>

                        </option>
                    <?php
}
}
?>
                </select>
                <br><br>
            </div>

            <div id="informacijeNovogPogona" style="display: none">

                <label for="noviNazivPogona">Naziv novog pogona: </label>
                <input class="okvirForme" type="text" id="noviNazivPogona" name="noviNazivPogona" value="nijePopunjeno"><br><br>

                <label for="noviOpisPogona">Opis novog pogona: </label>
                <input class="okvirForme" type="text" id="noviOpisPogona" name="noviOpisPogona" value="nijePopunjeno"><br><br>

            </div>

            <div class="gumbPrijava" style="float: right" onclick="dalje()" id="noviPogon">Želite li dodati novi pogon?</div>
            <div class="gumbPrijava" style="float: right;display: none;" id="natrag" onclick="unazad()">Vrati se</div>

            <input class="gumbPrijava" type="submit" name="dodavanjeNovogVlaka" value="Dodaj vlak">
            <a class="gumbPrijava" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
vlakovi/prikaz_vlakova_korisnika/">Odustani</a>
            </p>
        </form>
        <br>
    </div>
</section>
<?php }
}
