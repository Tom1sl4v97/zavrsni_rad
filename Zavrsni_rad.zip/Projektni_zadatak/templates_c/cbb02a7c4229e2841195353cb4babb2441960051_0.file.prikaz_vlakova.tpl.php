<?php
/* Smarty version 3.1.39, created on 2021-08-12 17:00:48
  from 'C:\xampp\htdocs\Projektni_zadatak\templates\Vlakovi\prikaz_vlakova.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_611537a0e47f57_82037745',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'cbb02a7c4229e2841195353cb4babb2441960051' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Projektni_zadatak\\templates\\Vlakovi\\prikaz_vlakova.tpl',
      1 => 1628162042,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_611537a0e47f57_82037745 (Smarty_Internal_Template $_smarty_tpl) {
?><link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
CSS/prikaz_forme.css"/>
<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
CSS/popUp_prozor.css"/>
<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
CSS/slider_slike.css"/>
<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
CSS/prikaz_izlozbe.css"/>


<section>
    <?php if ((isset($_smarty_tpl->tpl_vars['lista_vlakova']->value))) {?>
        <a class="gumbPrijava" style="float: right;margin-right: 1%;text-decoration: none" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
vlakovi/prikaz_podataka_kod_azuriranja_vlak/">Dodaj novi vlak</a>
        <h2 style="padding-bottom: 10px">
            Prikaz vaših dodanih vlakova:
        </h2>


        <div class="resetka">
            <?php
$__section_i_0_loop = (is_array(@$_loop=$_smarty_tpl->tpl_vars['lista_vlakova']->value) ? count($_loop) : max(0, (int) $_loop));
$__section_i_0_total = $__section_i_0_loop;
$_smarty_tpl->tpl_vars['__smarty_section_i'] = new Smarty_Variable(array());
if ($__section_i_0_total !== 0) {
for ($__section_i_0_iteration = 1, $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] = 0; $__section_i_0_iteration <= $__section_i_0_total; $__section_i_0_iteration++, $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']++){
?>
                <div style="margin-bottom: 20px; max-width: 400px">
                    <div class="izlozbaVlakova">
                        <div class="naslov">
                            <?php echo $_smarty_tpl->tpl_vars['lista_vlakova']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->naziv;?>

                        </div>
                        <div>
                            <div class="podkategorije">
                                <b>Opis vlaka:</b> <br><br> &nbsp;&nbsp; <?php echo $_smarty_tpl->tpl_vars['lista_vlakova']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->opis;?>
<br><br>
                                <b>Maximalna brzina vlaka: </b><?php echo $_smarty_tpl->tpl_vars['lista_vlakova']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->max_brzina;?>
 km/h<br><br>
                                <b>Ukupan broj sjedala: </b><?php echo $_smarty_tpl->tpl_vars['lista_vlakova']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->broj_sjedala;?>
<br><br>
                                <b>Naziv pogona: </b><?php echo $_smarty_tpl->tpl_vars['lista_vlakova']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->naziv_pogona;?>

                            </div>
                            <div style="padding: 0 5px">
                                <a class="dodaj" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
vlakovi/prikaz_podataka_kod_azuriranja_vlak/<?php echo $_smarty_tpl->tpl_vars['lista_vlakova']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->id;?>
">Uredi vlak</a>
                                <a class="dodaj" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
vlakovi/obrisi_valk_korisnika/<?php echo $_smarty_tpl->tpl_vars['lista_vlakova']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->id;?>
">Obriši vlak</a>
                            </div>
                            <?php $_smarty_tpl->_assignInScope('provjera', "da");?>
                            <?php
$__section_k_1_loop = (is_array(@$_loop=$_smarty_tpl->tpl_vars['slikaVlaka']->value) ? count($_loop) : max(0, (int) $_loop));
$__section_k_1_total = $__section_k_1_loop;
$_smarty_tpl->tpl_vars['__smarty_section_k'] = new Smarty_Variable(array());
if ($__section_k_1_total !== 0) {
for ($__section_k_1_iteration = 1, $_smarty_tpl->tpl_vars['__smarty_section_k']->value['index'] = 0; $__section_k_1_iteration <= $__section_k_1_total; $__section_k_1_iteration++, $_smarty_tpl->tpl_vars['__smarty_section_k']->value['index']++){
?>
                                <?php if ((isset($_smarty_tpl->tpl_vars['slikaVlaka']->value)) && $_smarty_tpl->tpl_vars['slikaVlaka']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_k']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_k']->value['index'] : null)]['IDVlaka'] == $_smarty_tpl->tpl_vars['lista_vlakova']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->id && $_smarty_tpl->tpl_vars['provjera']->value == 'da') {?>
                                    <div>
                                        <img src="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
/multimedija/vlak1.jpg" alt="<?php echo $_smarty_tpl->tpl_vars['slikaVlaka']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_k']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_k']->value['index'] : null)]['url'];?>
" style="width: 100%">
                                    </div>
                                    <?php $_smarty_tpl->_assignInScope('provjera', "ne");?>
                                <?php }?>
                            <?php
}
}
?>
                        </div>
                    </div>
                </div>
            <?php
}
}
?>
        </div>
    <?php } else { ?>
        <h2>
            Niste prijavili niti jedan vlak
            <form style="background-color: transparent; border: none; float: right;">
                <button type="submit" name="dodavanjeNovogVlaka" class="gumbPrijava" value="">Dodaj novi vlak</button>
            </form>
        </h2>
    <?php }?>
</section>
<?php }
}
