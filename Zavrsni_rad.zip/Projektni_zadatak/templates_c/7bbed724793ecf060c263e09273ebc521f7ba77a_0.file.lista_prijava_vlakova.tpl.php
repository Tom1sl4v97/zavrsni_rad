<?php
/* Smarty version 3.1.39, created on 2021-08-12 17:00:27
  from 'C:\xampp\htdocs\Projektni_zadatak\templates\Vlakovi\lista_prijava_vlakova.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_6115378b29dcc7_41111679',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '7bbed724793ecf060c263e09273ebc521f7ba77a' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Projektni_zadatak\\templates\\Vlakovi\\lista_prijava_vlakova.tpl',
      1 => 1628268973,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6115378b29dcc7_41111679 (Smarty_Internal_Template $_smarty_tpl) {
?><link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
CSS/prikaz_teblice.css"/>
<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
CSS/prikaz_forme.css"/>
<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
CSS/prikaz_izlozbe.css"/>
<!-- linkovi za js -->
<?php echo '<script'; ?>
 src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"><?php echo '</script'; ?>
> 
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
javascript/vlakoviAPI.js"><?php echo '</script'; ?>
>
<section>
    <?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
javascript/tablica.js"><?php echo '</script'; ?>
>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.24/css/jquery.dataTables.css">
    <?php echo '<script'; ?>
 type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.js"><?php echo '</script'; ?>
>

    <h2>
        Popis svih Vaših prijava vlakova na izložbu:
    </h2>
    <br>
    <?php if ((isset($_smarty_tpl->tpl_vars['prikaz_tablice']->value))) {?>
        <table id="myTable" class="prikazTablice" style="width: 95%">
            <thead>
                <tr>
                    <th>Redni broj</th>
                    <th colspan="3">Podaci korisnika</th>
                    <th>Naziv vlaka</th>
                    <th>Tematika</th>
                    <th>Datum početka</th>
                    <th>Status prijave</th>
                    <th>Potvrda</th>
                </tr>
            </thead>
            <tbody>
                <?php
$__section_i_0_loop = (is_array(@$_loop=$_smarty_tpl->tpl_vars['prikaz_tablice']->value) ? count($_loop) : max(0, (int) $_loop));
$_smarty_tpl->tpl_vars['__smarty_section_i'] = new Smarty_Variable(array('total' => $__section_i_0_loop));
if ($_smarty_tpl->tpl_vars['__smarty_section_i']->value['total'] !== 0) {
for ($__section_i_0_iteration = 1, $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] = 0; $__section_i_0_iteration <= $_smarty_tpl->tpl_vars['__smarty_section_i']->value['total']; $__section_i_0_iteration++, $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']++){
$_smarty_tpl->tpl_vars['__smarty_section_i']->value['index_next'] = $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] + 1;
?>
                    <?php if ($_smarty_tpl->tpl_vars['prikaz_tablice']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->vazi_do >= $_smarty_tpl->tpl_vars['virtualni_datum']->value || !$_smarty_tpl->tpl_vars['prikaz_tablice']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->vazi_do) {?>
                        <tr 
                            <?php if ($_smarty_tpl->tpl_vars['prikaz_tablice']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->status == 'Na čekanju') {?>
                                style="background-color: #93B080"
                            <?php } elseif ($_smarty_tpl->tpl_vars['prikaz_tablice']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->status == 'Odbijena') {?>
                                style="background-color: #D68B6F"
                            <?php }?>
                            >
                            <td><?php echo (isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index_next']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index_next'] : null);?>
</td>
                            <td><?php echo $_smarty_tpl->tpl_vars['prikaz_tablice']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->ime_korisnika;?>
</td>
                            <td><?php echo $_smarty_tpl->tpl_vars['prikaz_tablice']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->prezime_korisnika;?>
</td>
                            <td><?php echo $_smarty_tpl->tpl_vars['prikaz_tablice']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->korisnicko_ime;?>
</td>
                            <td><?php echo $_smarty_tpl->tpl_vars['prikaz_tablice']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->naziv;?>
</td>
                            <td><?php echo $_smarty_tpl->tpl_vars['prikaz_tablice']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->naziv_tematike;?>
</td>
                            <td><?php echo $_smarty_tpl->tpl_vars['prikaz_tablice']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->datum_pocetka_izlozbe;?>
</td>
                            <td><?php echo $_smarty_tpl->tpl_vars['prikaz_tablice']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->status;?>
</td>
                            <td>
                                <?php if ($_smarty_tpl->tpl_vars['prikaz_tablice']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->status == 'Potvrđena') {?>
                                    <a class="dodaj2" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
vlakovi/odbij_korisnika_na_izlozbu/<?php echo $_smarty_tpl->tpl_vars['prikaz_tablice']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->id;?>
">Odbij</a>
                                <?php } elseif ($_smarty_tpl->tpl_vars['prikaz_tablice']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->status == 'Odbijena') {?>
                                    <a class="dodaj2" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
vlakovi/prihvati_korisnika_na_izlozbu/<?php echo $_smarty_tpl->tpl_vars['prikaz_tablice']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->id;?>
">Prihvati</a>
                                <?php } else { ?>
                                    <a class="dodaj2" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
vlakovi/prihvati_korisnika_na_izlozbu/<?php echo $_smarty_tpl->tpl_vars['prikaz_tablice']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->id;?>
">Prihvati</a>
                                    <a class="dodaj2" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
vlakovi/odbij_korisnika_na_izlozbu/<?php echo $_smarty_tpl->tpl_vars['prikaz_tablice']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['index'] : null)]->id;?>
">Odbij</a>
                                <?php }?>
                            </td>
                        </tr>
                    <?php }?>
                <?php
}
}
?>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="8">Ukupno tematika vlakova:</td>
                    <td><?php echo (isset($_smarty_tpl->tpl_vars['__smarty_section_i']->value['total']) ? $_smarty_tpl->tpl_vars['__smarty_section_i']->value['total'] : null);?>
</td>
                </tr>
            </tfoot>
        </table>
    <?php }?>
</section>
<?php }
}
