<?php
/* Smarty version 3.1.39, created on 2021-08-14 15:49:22
  from 'C:\xampp\htdocs\Projektni_zadatak\templates\Izlozbe\azuriranje_tematike.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_6117c9e28c0844_22008423',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '7bfc8a114a6fb1437dcabf0e817af406a489b0e1' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Projektni_zadatak\\templates\\Izlozbe\\azuriranje_tematike.tpl',
      1 => 1628067048,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6117c9e28c0844_22008423 (Smarty_Internal_Template $_smarty_tpl) {
?><link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
/CSS/prikaz_forme.css"/>
<section id="sadrzajObrasca">
    <div>
        <form id ="form1" method="post" name="dodavanjeNoveTematike" action="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
izlozbe/azuriraj_tematiku/<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
">
            <br>
            
            <div id="greske" class="greska">
                <?php if ((isset($_smarty_tpl->tpl_vars['greska']->value))) {?>
                    <a><?php echo $_smarty_tpl->tpl_vars['greska']->value;?>
</a> <br>
                <?php }?>
            </div>

            <label for="nazivTematike">Naziv tematike: </label>
            <input class="okvirForme" type="text" id="nazivTematike" name="nazivTematike"
                   <?php if ((isset($_smarty_tpl->tpl_vars['naziv_tematike']->value))) {?>
                       value="<?php echo $_smarty_tpl->tpl_vars['naziv_tematike']->value;?>
"
                   <?php }?>>
            
            <br><br>
            
            <label for="OpisTematike">Opis tematike: </label>
            <input class="okvirForme" type="text" id="opisTematike" name="opisTematike"
                   <?php if ((isset($_smarty_tpl->tpl_vars['opis_tematike']->value))) {?>
                       value="<?php echo $_smarty_tpl->tpl_vars['opis_tematike']->value;?>
"
                   <?php }?>>
            
            <br><br>

            <input class="gumbPrijava" type="submit" name="dodajTematiku" value="Spremi">
            <a class="gumbPrijava" href="<?php echo $_smarty_tpl->tpl_vars['putanja']->value;?>
izlozbe/prikaz_administracija_izlozba/">Odustani</a>
            
            <br><br>
        </form>
    </div>
</section>
<?php }
}
