<?php
/* Smarty version 3.1.39, created on 2021-08-12 16:58:41
  from 'C:\xampp\htdocs\Projektni_zadatak\templates\dijeljeno\greske.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_611537210497e5_43595706',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '9a583c028f59049efa73ab3d35ee3df189d60c56' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Projektni_zadatak\\templates\\dijeljeno\\greske.tpl',
      1 => 1628098355,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_611537210497e5_43595706 (Smarty_Internal_Template $_smarty_tpl) {
?><section id="greske" >
    <?php
$__section_greska_0_loop = (is_array(@$_loop=$_smarty_tpl->tpl_vars['greske']->value) ? count($_loop) : max(0, (int) $_loop));
$__section_greska_0_total = $__section_greska_0_loop;
$_smarty_tpl->tpl_vars['__smarty_section_greska'] = new Smarty_Variable(array());
if ($__section_greska_0_total !== 0) {
for ($__section_greska_0_iteration = 1, $_smarty_tpl->tpl_vars['__smarty_section_greska']->value['index'] = 0; $__section_greska_0_iteration <= $__section_greska_0_total; $__section_greska_0_iteration++, $_smarty_tpl->tpl_vars['__smarty_section_greska']->value['index']++){
?>
        <div class="prikazGreske"> <?php echo $_smarty_tpl->tpl_vars['greske']->value[(isset($_smarty_tpl->tpl_vars['__smarty_section_greska']->value['index']) ? $_smarty_tpl->tpl_vars['__smarty_section_greska']->value['index'] : null)];?>

            <button type="button" class="zatvoriBtn" onClick="javascript:this.parentElement.remove();">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php
}
}
?>
</div>



<?php }
}
