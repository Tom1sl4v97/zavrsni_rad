$(document).ready( function () {
    $('#myTable').DataTable();
    $('#myTable2').DataTable();
} );