<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of korisniciDbRepozitorij
 *
 * @author franj
 */
include_once(ROOT . 'repositories/interfaces/Vrsta_pogona_repozitorij_interface.php');
include_once(ROOT . 'repositories/Dnevnik_db_repozitorij.php');
include_once(ROOT . 'repositories/database/Baza.php');
include_once(ROOT . 'models/Vrsta_pogona.php');
include_once(ROOT . 'utils/Postavke.php');

class Vrsta_pogona_db_repozitorij implements Vrsta_pogona_repozitorij_interface {

    private $_db;
    private $_dnevnik;
    private $_korisnicko_ime;

    public function __construct() {
        $this->_db = Baza::dohvati_instancu();
        $this->_dnevnik = new Dnevnik_db_repozitorij();
        $this->_korisnicko_ime = Sesija::dohvati_korisnicko_ime();
    }

    public function dohvati_prema_id($id) {
        throw new Exception('Onemogućena funkcionalnost.');
    }

    public function kreiraj($uneseni_podaci) {
        $vrsta_pogona = new Vrsta_pogona;

        $vrsta_pogona->naziv_pogona = $uneseni_podaci["noviNazivPogona"];
        $vrsta_pogona->opis_pogona = $uneseni_podaci["noviOpisPogona"];

        $sql = "INSERT INTO vrstapogona (naziv_pogona, opis) "
                . "VALUES ('{$vrsta_pogona->naziv_pogona}', '{$vrsta_pogona->opis_pogona}')";

        $this->_dnevnik->kreiraj_dnevnik($this->_korisnicko_ime, Tip_dnevnika::RAD_S_BAZOM, $sql);
        $this->_db->zapisi_podatke($sql);
    }

    public function dohvati_listu() {
        $popis_pogona = array();

        $sql = "SELECT * FROM vrstapogona";
        $rezultat_sqla_pogona = $this->_db->dohvati_podatke($sql);

        foreach ($rezultat_sqla_pogona as $model_sqla) {
            $vrsta_pogona = new Vrsta_pogona;

            $vrsta_pogona->id = $model_sqla["id"];
            $vrsta_pogona->naziv_pogona = $model_sqla["naziv_pogona"];
            $vrsta_pogona->opis_pogona = $model_sqla["opis"];

            array_push($popis_pogona, $vrsta_pogona);
        }

        return $popis_pogona;
    }

    public function obrisi($id_zapisa) {
        throw new Exception('Onemogućena funkcionalnost.');
    }

    public function azuriraj($uneseni_podaci) {
        throw new Exception('Onemogućena funkcionalnost.');
    }

    public function dohvati_id_vrste_pogona($model) {
        $vrsta_pogona = new Vrsta_pogona;

        $sql = "SELECT id FROM vrstapogona WHERE "
                . "naziv_pogona = '{$model["noviNazivPogona"]}' AND "
                . "opis = '{$model["noviOpisPogona"]}'";
        $rezultat_sqla_id_pogona = $this->_db->dohvati_podatke($sql);

        $vrsta_pogona->id = $rezultat_sqla_id_pogona[0]["id"];

        return $vrsta_pogona;
    }

}
