<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of korisniciDbRepozitorij
 *
 * @author franj
 */
include_once(ROOT . 'repositories/interfaces/Vrsta_materijala_repozitorij_interface.php');
include_once(ROOT . 'repositories/Dnevnik_db_repozitorij.php');
include_once(ROOT . 'repositories/database/Baza.php');
include_once(ROOT . 'utils/Postavke.php');
include_once (ROOT . 'models/Vrsta_materijala.php');

class Vrsta_materijala_db_repozitorij implements Vrsta_materijala_repozitorij_interface {

    private $_db;

    public function __construct() {
        $this->_db = Baza::dohvati_instancu();
    }

    public function dohvati_listu() {
        $sql = "SELECT * FROM vrstamaterijala";
        $rezultat_sqla_vrste_materijala = $this->_db->dohvati_podatke($sql);

        $popis_materijala = array();
        foreach ($rezultat_sqla_vrste_materijala as $model_sqla) {
            $vrsta_materijala = new Vrsta_materijala;

            $vrsta_materijala->id = $model_sqla["id"];
            $vrsta_materijala->format = $model_sqla["format"];

            array_push($popis_materijala, $vrsta_materijala);
        }
        return $popis_materijala;
    }

}
